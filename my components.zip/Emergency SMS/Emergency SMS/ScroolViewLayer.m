

#import "ScroolViewLayer.h"
#import "TPKeyboardAvoidingScrollView.h"

@interface ScroolViewLayer ()<UITextFieldDelegate>

@end

@implementation ScroolViewLayer

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    CGSize size=[UIScreen mainScreen].bounds.size;
    
    [self.view setBackgroundColor:[[UIColor alloc]initWithRed:0.7 green:0.7 blue:0.7 alpha:1]];
    
    TPKeyboardAvoidingScrollView *scrollView=[[TPKeyboardAvoidingScrollView alloc] initWithFrame:self.view.frame];
    scrollView.pagingEnabled=true;
    scrollView.backgroundColor=[UIColor whiteColor];
    scrollView.contentSize=CGSizeMake(self.view.frame.size.width, self.view.frame.size.height-44);
    [self.view addSubview:scrollView];
    
    UITextField *txtPass=[[UITextField alloc] initWithFrame:CGRectMake(50, 400,size.width-100,40)];
    txtPass.placeholder=@"Name";
    txtPass.delegate=self;
    txtPass.tag=1;
    txtPass.borderStyle=UITextBorderStyleRoundedRect;
    [scrollView addSubview:txtPass];
    
    txtPass=[[UITextField alloc] initWithFrame:CGRectMake(50, 500,size.width-100,40)];
    txtPass.placeholder=@"Pass";
    txtPass.tag=2;
    txtPass.delegate=self;
    txtPass.borderStyle=UITextBorderStyleRoundedRect;
    [scrollView addSubview:txtPass];
    
    
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
//    NSLog(@"%d",textField.tag);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
