
import UIKit


func setFont(size:CGFloat) ->UIFont
{
    var fontSize = size
    if UIScreen.mainScreen().bounds.height != 480
    {
        fontSize = size * (UIScreen.mainScreen().bounds.size.height / 568)
    }
    return UIFont (name: "HelveticaNeue", size: fontSize)!
}
class TCFormValidator {
    
    var name: String = ""
//    var age: Int = 0
    
    init (name: String) {
        self.name = name
//        self.age = age
    }
    
    
    static func isEmpty(str:String) ->Bool
    {
        if str.characters.count == 0
        {
            return false
        }
        else
        {
            return true
        }
    }
    static func isValidEmail(testStr:String) -> Bool
    {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr)
    }
    static func isMinimumLength(str:String,len:Int)->Bool
    {
        
        if str.characters.count >= len //str.length >= len
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    func validatePasswordLength(PasswordValue : String) ->Bool{
//         let isValid = false
        let PASSWORD_REGEX = "((?=.*[0-9]).{5,25})"
          let pswrdTest = NSPredicate(format: "SELF MATCHES %@", PASSWORD_REGEX)
        if (PasswordValue.characters.count  < 6 || PasswordValue.characters.count > 16)
        {
            return false
        }
        else{
            if pswrdTest.evaluateWithObject(PasswordValue)
            {
                return true
            }
            else{
                 return false
            }
        }
//        return isValid
        
        
    }
    
    static func isvalidatePhoneNumber(value: String) -> Bool {

       let PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        if phoneTest.evaluateWithObject(value) {
            return true
        }
        return false
    }
    
    //or
    
   static  func validPhoneNumber(phone : String) -> Bool
    {
        if phone.characters.count < 7 || phone.characters.count > 10
        {
            return false
        }
        
//        var testBool = false
       let phoneRegexUS5 = "[0-9]*"
        let test2 = NSPredicate(format: "SELF MATCHES %@", phoneRegexUS5)
        if test2.evaluateWithObject(phone)
        {
            return true
        }
        return false
        
        
    }
    func isvalidatePassword(value: String) -> Bool {
    let PASSWORD_REGEX = "^(?=.*?[A-Z]).{8,}$"
    let passwordTes = NSPredicate(format: "SELF MATCHES %@", PASSWORD_REGEX)
        if passwordTes.evaluateWithObject(value)
            {
                return true
            }
            return false
    }
    
    static func isValidateComparePasswords( password: NSString  , confirmPassword : NSString) -> Bool
    {
        if password != confirmPassword
        {
//          error = "New Password and Confirm New Password doesn't not match"
            return false
        }
        else
        {
            return (password .isEqualToString(confirmPassword as String))
        }
        return true
        
    }
    func isValidateWebsite(myWebsite : NSString ) -> Bool
    {
    
        var isValid = false
        
        let urlRegEx = "(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+"
         let urlTest = NSPredicate(format: "SELF MATCHES %@", urlRegEx)
        if urlTest.evaluateWithObject(myWebsite)
        {
            isValid = true
//            error = ""
        }
        else
        {
//            error = "Invalid Website address"
            isValid = false
        }
        return isValid
        
        
    }
    
    func isValidateAlphaNumeric(textValue : NSString) -> Bool
    {
        var isValid = false
         let urlRegEx = "^(?=.*\\d)(?=.*[A-Za-z]).{5,20}$"
         let urlTest = NSPredicate(format: "SELF MATCHES %@", urlRegEx)
        if urlTest.evaluateWithObject(textValue)
        {
            isValid = true
           
        }
        else{
            isValid = false
        }
        return isValid
        
    }
    
    //or
    func isValidateContainsOnlyLetters(textValue: String) -> Bool {
        for chr in textValue.characters {
            if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") ) {
                return false
            }
        }
        return true
    }
    
    func isvalidateCalculateAge(strDate: String) -> NSInteger {
        
        let dateString = strDate
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        let birthday = dateFormatter.dateFromString(dateString)
        let calendar : NSCalendar = NSCalendar.currentCalendar()
        
        let ageComponents = calendar.components(.Year,
            fromDate: birthday!,
            toDate: NSDate(),
            options: [])
        
        return ageComponents.year
    }

    func removeSpecialCharsFromString(text: String) -> String {//check
        let okayChars : Set<Character> =
        Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890+-*=(),.:!_".characters)
        return String(text.characters.filter {okayChars.contains($0) })
    }
    
      func validateSpecialChars(strText : NSString) -> Bool
      {
        var isValid = false
      
        let emailRegex = "[A-Z0-9a-z]*"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
         if emailTest.evaluateWithObject(strText)
         {
            isValid = true
        }
        else
         {
             isValid = false
        }
        return isValid

    }
    func isvalidateAlphabet(var username : NSString) -> Bool //remove numbers
    {
       var isValid = false
           var iSecondTest = false
       let nameRegex = "^[A-Za-z.]{5,90}$" //"^[A-Z0-9a-z.]{5,90}$"
        let test = NSPredicate(format: "SELF MATCHES %@", nameRegex)
          if test.evaluateWithObject(username)
          {
              isValid = true
        }
          else{
            isValid = false
        }
        username = (username .stringByReplacingOccurrencesOfString(".", withString: ""))
        iSecondTest = (username .isEqualToString(""))
        
        return isValid && !iSecondTest
    }
    
       
 
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
 class LanguageManager: NSObject {
    private var name:NSString?
    var languageCode:NSString?
    var countryCode:NSString?
     var availableLocales = [LanguageManager]()
    var DEFAULTS_KEY_LANGUAGE_CODE:NSString = NSString()
    
   internal func initWithLanguageCode(languageCode: NSString,countryCode:NSString,name: NSString,locale : LanguageManager)->AnyObject{
        self.name = name
        self.languageCode = languageCode
        self.countryCode = countryCode
        print("\(locale.languageCode)")
        NSUserDefaults.standardUserDefaults().setObject(locale.languageCode, forKey: "DEFAULTS_KEY_LANGUAGE_CODE")
        return self
    }
    
    override init() {
        
         super.init()
        
        let english = self
        english.initWithLanguageCode("en", countryCode: "gb", name: "United Kingdom", locale: self)
        

              let thai  = self
        thai.initWithLanguageCode("th", countryCode: "thai", name: "Thailand" , locale: self)
        
      
        self.availableLocales = [english , thai]
        
        
    }
      
    class var sharedInstance: LanguageManager {
        
        
        struct Static {
            static var instance: LanguageManager?
            static var token: dispatch_once_t = 0
        }
        
        dispatch_once(&Static.token) {
            Static.instance = LanguageManager()
        }
        
        return Static.instance!
    }
    func getTranslationForKey(key: NSString)->NSString {
        
//        // Get the language code.
       print("language code after is \(self.getLanguageCode())")
        let languageCode =  NSUserDefaults.standardUserDefaults().stringForKey("DEFAULTS_KEY_LANGUAGE_CODE")
        
        // Get language bundle that is relevant.
        let bundlePath = NSBundle.mainBundle().pathForResource(languageCode as String?, ofType: "lproj")
        let Languagebundle = NSBundle(path: bundlePath!)
        
        // Get the translated string using the language bundle.
        let translatedString = Languagebundle?.localizedStringForKey(key as String, value:"", table: nil)
        return translatedString!;
    }
    
    func getLanguageCode()->NSString {
        
        // language code is saved as constant on #languaeManager class as DEFAULTS_KEY_LANGUAGE_CODE
        let languageCode = LanguageManager.sharedInstance.DEFAULTS_KEY_LANGUAGE_CODE
        print("The Selected Language code is  \(languageCode)")
        return languageCode
    }
    
    func customLocalizedString(key: NSString,comment: NSString)->NSString{
        return LanguageManager.sharedInstance.getTranslationForKey(key)
        
    }
}
//class Example : LanguageManager {
//    
//    func testMethod(exmplName : String)
//    {
//       self.name = exmplName
//        
//    }
//}

