//
//  TCAddressBook.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/7/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit
import AddressBook


class Singleton
{
    class var sharedInstance: Singleton
    {
        struct Static
        {
            static var onceToken: dispatch_once_t = 0
            static var instance: Singleton? = nil
        }
        dispatch_once(&Static.onceToken){
            Static.instance = Singleton()
        }
        return Static.instance!
    }
    init()
    {
        
    }
}


class TCAddressBook: NSObject
{
    
    private var arrContactList:NSMutableArray!
    class var sharedInstance: TCAddressBook
    {
        struct Static
        {
            static var onceToken: dispatch_once_t = 0
            static var instance: TCAddressBook? = nil
        }
        dispatch_once(&Static.onceToken){
            Static.instance = TCAddressBook()
        }
        return Static.instance!
    }
    override init()
    {
        super.init()
        self.arrContactList = NSMutableArray()
        
        let status = ABAddressBookGetAuthorizationStatus()
        if status == .Denied || status == .Restricted {
            TCAlert.sharedInstance().show(alertTitle, message:"user previously denied, so tell them to fix that in settings", buttonsTitle: ["Ok"], willHideAlert: { (buttonIndex) -> Void in
            })
            return
        }
        var error: Unmanaged<CFError>?
        guard let addressBook: ABAddressBook? = ABAddressBookCreateWithOptions(nil, &error)?.takeRetainedValue() else {
            print(error?.takeRetainedValue())
            return
        }
        
        ABAddressBookRequestAccessWithCompletion(addressBook) { granted, error in
            if !granted {
                TCAlert.sharedInstance().show(alertTitle, message:"warn the user that because they just denied permission, this functionality won't work. also let them know that they have to fix this in settings", buttonsTitle: ["Ok"], willHideAlert: { (buttonIndex) -> Void in
                })
                return
            }
            if let people = ABAddressBookCopyArrayOfAllPeople(addressBook)?.takeRetainedValue(){
                for person in people {
                    var dictInfo = [String:AnyObject]()
                    let firstNameTemp = ABRecordCopyValue(person, kABPersonFirstNameProperty)
                    
                    if firstNameTemp != nil {
                     
                        let firstName: NSObject! = Unmanaged<NSObject>.fromOpaque(firstNameTemp.toOpaque()).takeRetainedValue()
                        
                        if (firstName != nil) {
                            dictInfo["firstName"] = firstName as? String
                        } else {
                            dictInfo["firstName"] = ""
                        }
                    } else {
                        dictInfo["firstName"] = ""
                    }
                    
                    
                    let lastNameTemp = ABRecordCopyValue(person, kABPersonLastNameProperty)
                    if lastNameTemp != nil {
                     
                        let lastName: NSObject! = Unmanaged<NSObject>.fromOpaque(lastNameTemp.toOpaque()).takeRetainedValue()
                        
                        if (lastName != nil) {
                            dictInfo["lastName"] = lastName as? String
                        } else {
                            dictInfo["lastName"] = ""
                        }
                        
                    } else {
                        dictInfo["lastName"] = ""
                    }
                    
                    let unmanagedPhones = ABRecordCopyValue(person, kABPersonPhoneProperty)
                    let phones: ABMultiValueRef =
                    Unmanaged.fromOpaque(unmanagedPhones.toOpaque()).takeUnretainedValue()
                        as NSObject as ABMultiValueRef
                    
                    let countOfPhones = ABMultiValueGetCount(phones)
                    
                    let arrMobile = NSMutableArray()
                    for index in 0..<countOfPhones{
                        let unmanagedPhone = ABMultiValueCopyValueAtIndex(phones, index)
                        let phone: String = Unmanaged.fromOpaque(
                            unmanagedPhone.toOpaque()).takeUnretainedValue() as NSObject as! String
                        arrMobile.addObject(phone)
                    }
                    dictInfo["numbers"] = arrMobile
                    self.arrContactList.addObject(dictInfo)
                }
                //print(self.arrContactList)
            }
        }

    }
    func getAllContact() -> NSArray
    {
        return (self.arrContactList as NSArray)
    }
}

extension CFArray: SequenceType {
    public func generate() -> AnyGenerator<AnyObject> {
        var index = -1
        let maxIndex = CFArrayGetCount(self)
        return AnyGenerator{
            guard ++index < maxIndex else {
                return nil
            }
            let unmanagedObject: UnsafePointer<Void> = CFArrayGetValueAtIndex(self, index)
            let rec = unsafeBitCast(unmanagedObject, AnyObject.self)
            return rec
        }
    }
}

class TCPerson : NSObject
{
    var firstName : String = ""
    var lastName : String = ""
    var numbers  = NSArray()
    
    init(dictPeople:NSDictionary)
    {
        super.init()
        for (key, value) in dictPeople {
            let keyName = key
            let keyValue = value 
            if (self.respondsToSelector(NSSelectorFromString(keyName as! String))) {
                self.setValue(keyValue, forKey: keyName as! String)
            }
        }
    }
}






