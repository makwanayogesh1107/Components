//
//  SignupVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/1/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class SignupVC: BaseViewController
{
    
    var scrollView:TPKeyboardAvoidingScrollView!
    var txtFirst:TCTextField!
    var txtLast:TCTextField!
    var txtEmail:TCTextField!
    var txtPass:TCTextField!
    var txtConFass:TCTextField!
    var txtMobile:TCTextField!
    var txtSecurityQ:TCTextField!
    var txtAnswer:TCTextField!
    var btnMale:UIButton!
    var btnFemale:UIButton!
    var gender = "1"
    var btnAgree:UIButton!
    var lblAgree:UILabel!
    var btnPrivacyPolicy:UIButton!
    var btnCamera:UIButton!
    var btnUserProfile:UIButton!
    var imgCamera:UIImage!
    var strAlertMessage:String!
    var btnSignUp:UIButton!
    var isImageSelected = false
    var imageUser: UIImage?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Sign Up"
        
        scrollView = TPKeyboardAvoidingScrollView(frame:TCRectMake(x: 0, y: 0, width: 320, height: 568))
        self.view.addSubview(scrollView)
        
        btnUserProfile = UIButton(frame: TCRectMake(x:110, y: 56, width: 100, height: 100))
        btnUserProfile.setImage(UIImage(named: "imgUserProfile"), forState: UIControlState.Normal)
        btnUserProfile.adjustsImageWhenHighlighted = false
        btnUserProfile.layer.cornerRadius = btnUserProfile.frame.size.height / 2
        btnUserProfile.clipsToBounds = true
        scrollView.addSubview(btnUserProfile)
        
        if DeviceType.IS_IPHONE_4_OR_LESS || DeviceType.IS_IPHONE_5
        {
            btnCamera = UIButton(frame: TCRectMake(x: 185.5, y: 68, width: 50, height: 50))
        }
        else if DeviceType.IS_IPHONE_6
        {
            btnCamera = UIButton(frame: TCRectMake(x: 178.7, y: 72.5, width: 50, height: 50))
        }
        else if DeviceType.IS_IPHONE_6P
        {
            btnCamera = UIButton(frame: TCRectMake(x: 187, y: 67, width: 50, height: 50))
        }
        else
        {
            btnCamera = UIButton(frame: TCRectMake(x: 187, y: 67, width: 50, height: 50))
        }
        btnUserProfile.addTarget(self, action: Selector("tappedOnCamera"), forControlEvents: UIControlEvents.TouchUpInside)
        btnCamera.setImage(UIImage(named: "imgCamera"), forState: UIControlState.Normal)
        //scrollView.addSubview(btnCamera)
        
        txtFirst = TCTextField(frame:TCRectMake(x: 35,y: btnUserProfile.frame.relativeheight + btnUserProfile.frame.relativeY + 20,width: 250,height: 45))
        txtFirst.setGUI("First Name")
        scrollView.addSubview(txtFirst)
        
        txtLast = TCTextField(frame:TCRectMake(x: 35,y: txtFirst.frame.relativeheight + txtFirst.frame.relativeY + 5,width: 250,height: 45))
        txtLast.setGUI("Last Name")
        scrollView.addSubview(txtLast)
        
        txtEmail = TCTextField(frame:TCRectMake(x: 35,y: txtLast.frame.relativeheight + txtLast.frame.relativeY + 5,width: 250,height: 45))
        txtEmail.setGUI("Email")
        txtEmail.autocapitalizationType = .None
        scrollView.addSubview(txtEmail)
        
        txtPass = TCTextField(frame:TCRectMake(x: 35,y: txtEmail.frame.relativeheight + txtEmail.frame.relativeY + 5,width: 250,height: 45))
        txtPass.setGUI("Password")
        txtPass.secureTextEntry = true
        scrollView.addSubview(txtPass)
        
        txtConFass = TCTextField(frame:TCRectMake(x: 35,y: txtPass.frame.relativeheight + txtPass.frame.relativeY + 5,width: 250,height: 45))
        txtConFass.secureTextEntry = true
        txtConFass.setGUI("Confirm Password")
        scrollView.addSubview(txtConFass)
        
        txtMobile = TCTextField(frame:TCRectMake(x: 35,y: txtConFass.frame.relativeheight + txtConFass.frame.relativeY + 5,width: 250,height: 45))
        txtMobile.setGUI("Mobile Number")
        txtMobile.keyboardType = .PhonePad
        txtMobile.setInputHeaderWith(Color.themeRed, textColor:UIColor.whiteColor(), doneTitle:"Done", prevTitle:"", nextTitle:"Next", doneBlock: { (textField) -> () in
            
            }, nextBlock: { (textField) -> () in
                self.txtSecurityQ.becomeFirstResponder()
            }) { (textField) -> () in
                
        }
        scrollView.addSubview(txtMobile)
        
        txtSecurityQ = TCTextField(frame:TCRectMake(x: 35,y: txtMobile.frame.relativeheight + txtMobile.frame.relativeY + 5,width: 250,height: 45))
        txtSecurityQ.setGUI("Choose a security questions")
        txtSecurityQ.setInputTypeList([
            "What is Last Name of thr teacher who gave you first faling grade",
            "Name your favourite pop singer",
            "Write s wolrd that explain you best"
            ])
        txtSecurityQ.tblList?.rowHeight = 50
        txtSecurityQ.setInputHeaderWith(Color.themeRed, textColor:UIColor.whiteColor(), doneTitle:"Done", prevTitle:"", nextTitle:"Next", doneBlock: { (textField) -> () in
            
            }, nextBlock: { (textField) -> () in
                self.txtAnswer.becomeFirstResponder()
                
            }) { (textField) -> () in
                
        }
        scrollView.addSubview(txtSecurityQ)
        
        
        txtAnswer = TCTextField(frame:TCRectMake(x: 35,y: txtSecurityQ.frame.relativeheight + txtSecurityQ.frame.relativeY + 5,width: 250,height: 45))
        txtAnswer.setGUI("Answer")
        scrollView.addSubview(txtAnswer)
        
        //Male
        btnMale = UIButton(frame: TCRectMake(x: 35, y: txtAnswer.frame.relativeheight + txtAnswer.frame.relativeY + 5, width: 80, height: 35))
        btnMale.addTarget(self, action: Selector("tappedOnMale:"), forControlEvents: UIControlEvents.TouchUpInside)
        btnMale.setTitle("  Male", forState: UIControlState.Normal)
        btnMale.setTitleColor(Color.textColor, forState: UIControlState.Normal)
        btnMale.titleLabel?.font = Font(FontName.HelveticaNeue, size: 13)
        btnMale.tag = 1
        btnMale.setImage(UIImage(named: "imgRadioButtonOn"), forState: UIControlState.Normal)
        scrollView.addSubview(btnMale)
        
        //Female
        btnFemale = UIButton(frame: TCRectMake(x: 165, y: txtAnswer.frame.relativeheight + txtAnswer.frame.relativeY + 5, width: 80, height: 35))
        btnFemale.addTarget(self, action: Selector("tappedOnMale:"), forControlEvents: UIControlEvents.TouchUpInside)
        btnFemale.setTitle("  Female", forState: UIControlState.Normal)
        btnFemale.setTitleColor(Color.textColor, forState: UIControlState.Normal)
        btnFemale.titleLabel?.font = Font(FontName.HelveticaNeue, size: 13)
        btnFemale.setImage(UIImage(named: "imgRadioButtonOff"), forState: UIControlState.Normal)
        btnFemale.tag = 0
        scrollView.addSubview(btnFemale)
        
        //Agree
        btnAgree = UIButton(frame: TCRectMake(x: 45, y: btnFemale.frame.relativeheight + btnFemale.frame.relativeY + 5, width: 25, height: 25))
        btnAgree.addTarget(self, action: Selector("tappedOnAgree:"), forControlEvents: UIControlEvents.TouchUpInside)
        //btnAgree.setTitle("  I Agree to", forState: UIControlState.Normal)
        btnAgree.setImage(UIImage(named: "imgAgreeNotSelected"), forState: UIControlState.Normal)
        btnAgree.tag = 0
        scrollView.addSubview(btnAgree)
        
        lblAgree = UILabel(frame: TCRectMake(x: 80, y: btnFemale.frame.relativeheight + btnFemale.frame.relativeY , width: 75, height: 35))
        lblAgree.text = "I Agree to"
        lblAgree.textColor = Color.textColor
        lblAgree.font = Font(FontName.HelveticaNeue, size: 13)
        scrollView.addSubview(lblAgree)
        
        //Privacy Policy
        btnPrivacyPolicy = UIButton(frame: TCRectMake(x: 140, y: btnFemale.frame.relativeheight + btnFemale.frame.relativeY, width: 150, height: 35))
        btnPrivacyPolicy.addTarget(self, action: Selector("tappedOnPrivacyPolicy"), forControlEvents: UIControlEvents.TouchUpInside)
        btnPrivacyPolicy.setTitle("T&C and Privacy Policy", forState: UIControlState.Normal)
        btnPrivacyPolicy.setTitleColor(Color.themeRed, forState: UIControlState.Normal)
        btnPrivacyPolicy.tag = 0
        btnPrivacyPolicy.titleLabel?.font = Font(FontName.HelveticaNeue, size: 13)
        let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.StyleSingle.rawValue]
        let underlineAttributedForgotPrivacy = NSAttributedString(string: "T&C and Privacy Policy", attributes: underlineAttribute)
        btnPrivacyPolicy.titleLabel?.attributedText = underlineAttributedForgotPrivacy
        scrollView.addSubview(btnPrivacyPolicy)
    
        //Signup Button
        btnSignUp = UIButton(frame:TCRectMake(x: 35,y: btnPrivacyPolicy.frame.relativeheight + btnPrivacyPolicy.frame.relativeY + 10,width: 250,height: 45))
        btnSignUp.setTitle("Sign Up", forState: UIControlState.Normal)
        btnSignUp.addTarget(self, action: Selector("tappedOnSignUp"), forControlEvents: UIControlEvents.TouchUpInside)
        btnSignUp.layer.cornerRadius = 5
        btnSignUp.titleLabel?.font = Font(FontName.HelveticaNeueBold, size: 14)
        btnSignUp.backgroundColor = Color.themeRed
        btnSignUp.setTitleColor(UIColor.grayColor(), forState: .Highlighted)
        scrollView.addSubview(btnSignUp)
        
       // scrollView.contentSize = CGSizeMake(Screen.width,btnSignUp.frame.relativeheight + btnSignUp.frame.relativeY + 150)

    }
    override func viewDidAppear(animated: Bool) {
        super.viewWillAppear(animated)
        scrollView.contentSize = CGSizeMake(Screen.width,btnSignUp.frame.origin.y + btnSignUp.frame.height + 10)
        
    }
    func tappedOnMale(sender:UIButton)
    {
        btnMale.setImage(UIImage(named: "imgRadioButtonOff"), forState: UIControlState.Normal)
        btnFemale.setImage(UIImage(named: "imgRadioButtonOff"), forState: UIControlState.Normal)
        sender.setImage(UIImage(named: "imgRadioButtonOn"), forState: UIControlState.Normal)
        gender = sender.tag  == 1 ? "1" : "0"
        
    }
    func tappedOnCamera()
    {
        print("Tapped on camera")
        
        TCImagePicker.sharedInstance().openImagePicker("Select Image", cancelTitle:"Cancel", cameraTitle:"Camera", galleryTitle:"Library", isImage:true, isMultipleSelection:false, completeHandler: { (success, arrAssert) -> Void in
            
                self.btnUserProfile.setImage(arrAssert[0].thumbnailImage, forState: UIControlState.Normal)
                self.imageUser = arrAssert[0].thumbnailImage
                self.isImageSelected = true
            
            }) { (error) -> (Void) in
                
        }
        
        
    }
    func tappedOnAgree(sender:UIButton)
    {
        if sender.tag == 0
        {
            sender.setImage(UIImage(named: "imgAgreeSelected"), forState: UIControlState.Normal)
            sender.tag = 1
        }
        else
        {
            sender.setImage(UIImage(named: "imgAgreeNotSelected"), forState: UIControlState.Normal)
            sender.tag = 0
        }
    }
    func tappedOnPrivacyPolicy()
    {
        print("tapped On Privacy Policy \(btnPrivacyPolicy.tag)")
        
    }
    func isFormValid() ->Bool
    {
        if txtFirst.text?.isEmpty == true
        {
            strAlertMessage = "Please enter first name."
            return false
        }
        else if containsOnlyLetters(txtFirst.text!) == false
        {
            strAlertMessage = "First name should only contain alphabets."
            return false
        }
        else if txtLast.text?.isEmpty == true
        {
            strAlertMessage = "Please enter last name."
            return false
        }
        else if containsOnlyLetters(txtLast.text!)  == false
        {
            strAlertMessage = "Last name should only contain alphabets."
            return false
        }
        else if txtEmail.text?.isEmpty == true
        {
            strAlertMessage = "Please enter email."
            return false
        }
        else if isValidEmail(txtEmail.text!) == false
        {
            strAlertMessage = "Please enter valid email."
            return false
        }
        else if txtPass.text?.isEmpty == true
        {
            strAlertMessage = "Please enter password."
            return false
        }
        else if isValidRange(8, maxNo: 16, strMessage: txtPass.text!)
        {
            strAlertMessage = "Please enter password between 8 to 16 characters."
            return false
        }
        else if isPasswordSame(txtPass.text!, confirmPassword: txtConFass.text!) == false
        {
            strAlertMessage = "Password does not match."
            return false
        }
        else if txtMobile.text?.isEmpty == true
        {
            strAlertMessage = "Enter mobile number."
            return false
        }
        else if isValidPhoneNumber(txtMobile.text!) == true
        {
            strAlertMessage = "Enter valid mobile number."
            return false
        }
        else if isValidRange(8, maxNo: 12, strMessage: txtMobile.text!)
        {
            strAlertMessage = "Please enter valid phone number."
            return false
        }
        else if txtSecurityQ.text?.isEmpty == true
        {
            strAlertMessage = "Choose a security question."
            return false
        }
        else if txtAnswer.text?.isEmpty == true
        {
            strAlertMessage = "Please enter answer."
            return false
        }
        else if btnAgree.tag == 0
        {
            strAlertMessage = "Please accept privacy policy."
            return false
        }
        else
        {
            strAlertMessage = "Registration successfully."
            return true
        }
    }
    func tappedOnSignUp()
    {
        if isFormValid()
        {
            signUpApi()
        }
        else
        {
            print("Form is not valid : \(strAlertMessage)")
            TCAlert().show(alertTitle, message:strAlertMessage, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
            })
        }
    }
    func signUpApi()
    {
        
        var dictUser = [String : AnyObject]()
        
        
        dictUser["firstName"] = txtFirst.text!
        dictUser["lastName"] = txtLast.text!
        dictUser["email"] = txtEmail.text!
        dictUser["mobile"] =  txtMobile.text!
        dictUser["question"] = txtSecurityQ.text!
        dictUser["answer"] = txtAnswer.text!
        dictUser["gender"] = gender
        dictUser["password"] = txtPass.text!
        

        
        var arrImgs = [NSDictionary]()
        if isImageSelected {
            arrImgs.append([
                "fileKey" : "profile","fileName" : "avtar_\(Int(NSDate().timeIntervalSince1970)).jpg","mimeType" : "image/jpeg","file" : UIImageJPEGRepresentation(self.imageUser!, 0.3)!,
                ])
        }
        
        if arrImgs.count > 0 {
            dictUser["imgData"] = arrImgs
        }
        
        self.view.endEditing(true)
        Helper.sharedInstance.request.requestFor(requestURL:baseURL + signUp,
            type:self.isImageSelected == true ?  RequestType.MULTIPART :RequestType.POST ,
            parameters:dictUser).onProgress { (request, total, sent, type) -> () in
            }.onSuccess { (request, response, error) -> () in
                
                dispatch_async(dispatch_get_main_queue(),{
                    if error != nil
                    {
                        print(error?.localizedDescription)
                        TCAlert.sharedInstance().show(alertTitle, message:(error?.localizedDescription)!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                            
                        })
                    }
                    else
                    {
                        print(response)
                        if (response!["data"]!!["status"] as? NSNumber)?.integerValue == 1
                        {
                            let errorMsg = response!["data"]!!["msg"] as? String
                            TCAlert.sharedInstance().show(alertTitle, message:(errorMsg)!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                                
                                if let userID = response!["data"]!!["register_id"]  as? String {
                                    dictUser["register_id"] = userID
                                }
                                
                                dictUser["registerId"] = response!["data"]!!["register_id"]
                                Helper.sharedInstance.dictUser = dictUser 
                                NSUserDefaults.standardUserDefaults().setObject(dictUser, forKey:"userInfro")
                                
                                let appDel = UIApplication.sharedApplication().delegate as! AppDelegate
                                appDel.nvController = UINavigationController(rootViewController:HomeVC())
                                appDel.nvController.navigationBarHidden = true
                                let slideVC = ExSlideMenuController(mainViewController:appDel.nvController, leftMenuViewController:LeftSliderVC())
                                slideVC.automaticallyAdjustsScrollViewInsets = true
                                slideVC.closeLeft()
                                appDel.window?.backgroundColor = UIColor(red: 236.0, green: 238.0, blue: 241.0, alpha: 1.0)
                                appDel.window?.rootViewController = slideVC
                            })
                            
                        }
                        else
                        {
                            let errorMsg = response!["data"]!!["msg"] as? String
                            TCAlert.sharedInstance().show(alertTitle, message:errorMsg!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                            })
                        }
                    }
                })
        }
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }

}
