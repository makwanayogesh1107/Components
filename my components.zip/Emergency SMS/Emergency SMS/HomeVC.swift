//
//  HomeVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/4/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        title = "Home"
        
        let btnMenu = UIButton(frame:CGRectMake(10,20,34,34))
        btnMenu.setImage(UIImage(named:"menu_icon"), forState: UIControlState.Normal)
        btnMenu.addTarget(self, action:"openSlider", forControlEvents: UIControlEvents.TouchUpInside)
        self.viewHeader.addSubview(btnMenu)
    }
    func openSlider()
    {
        self.openLeft()
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }

}
