//
//  ContactCell.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/7/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class ContactCell: UITableViewCell {

    var imgView:UIImageView!
    var lblName:UILabel!
    var btnView:UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override init(style: UITableViewCellStyle, reuseIdentifier: String?)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.clipsToBounds = true
        self.backgroundColor = UIColor.whiteColor()
        imgView = UIImageView(frame:TCRectMake(x:15, y:7, width:30, height: 30))
        imgView.contentMode = .ScaleAspectFit
        imgView.backgroundColor = UIColor.clearColor()
        imgView.clipsToBounds = true
       // self.contentView.addSubview(imgView)
        
        lblName = UILabel(frame:TCRectMake(x: 30,y:7,width: 200,height: 30))
        lblName.textColor = Color.textColor
        lblName.font = Font(FontName.HelveticaNeueBold, size: 14)
        self.contentView.addSubview(lblName)
        
        btnView = UIButton(type: UIButtonType.Custom)
        btnView.frame = TCRectMake(x: 250,y: 10,width: 50,height: 24)
        btnView.layer.cornerRadius = 5
        btnView.backgroundColor = Color.themeRed
        btnView.titleLabel?.font = Font(FontName.HelveticaNeueBold, size: 13)
        btnView.setTitle("view", forState: UIControlState.Normal)
        self.contentView.addSubview(btnView)
        
        let line = UIView(frame:TCRectMake(x: 0,y: 43,width: 320,height: 1))
        line.backgroundColor = Color.lightDark
        line.frame.size.height = 0.5
        self.contentView.addSubview(line)
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
