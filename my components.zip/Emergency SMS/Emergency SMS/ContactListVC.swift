//
//  ContactListVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/7/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit
import AddressBook

class ContactListVC: BaseViewController,UITableViewDataSource,UITableViewDelegate
{
    var tblContact:UITableView!
    var arrMenu:NSArray!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        title = "All Contacts"
        
        arrMenu = TCAddressBook.sharedInstance.getAllContact()
        tblContact = UITableView(frame: CGRectMake(0,44,Screen.width,Screen.height))
        tblContact.rowHeight = Screen.height == 480 ? 44 : 44 * (Screen.width / 320)
        tblContact.dataSource = self
        tblContact.delegate = self
        tblContact.clipsToBounds = true
        tblContact.separatorStyle = .None
        self.view.addSubview(tblContact)
        
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        print(arrMenu)
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return  arrMenu.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCellWithIdentifier("ContactCell\(indexPath.row)") as? ContactCell
        if cell == nil {
            cell = ContactCell(style: UITableViewCellStyle.Default, reuseIdentifier:("ContactCell\(indexPath.row)"))
            cell?.selectionStyle = .None
            cell?.btnView.tag = indexPath.row
            cell?.btnView.addTarget(self, action:"btnViewClick:", forControlEvents: UIControlEvents.TouchUpInside)
        }
        let people = TCPerson(dictPeople:arrMenu[indexPath.row] as! NSDictionary)
        cell?.lblName.text = people.firstName + " " + people.lastName
        return cell!
    }
    func btnViewClick(sender:UIButton)
    {
    
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
}
