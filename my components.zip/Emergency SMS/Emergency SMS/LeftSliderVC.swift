//
//  LeftSliderVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/4/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class LeftSliderVC: UIViewController,UITableViewDataSource,UITableViewDelegate
{

    var tblMenu:UITableView!
    var arrMenu:NSArray!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = Color.cellBack
        
        arrMenu = NSArray(array:[
                "Home",
                "Profile",
                "Options",
                "Share Us",
                "Need Help?",
                "Logout"
            ])
        
        tblMenu = UITableView(frame: TCRectMake(x: 0,y:40,width:Screen.width / 2,height: 568))
        tblMenu.rowHeight = Screen.height == 480 ? 50 : 50 * (Screen.width / 320)
        tblMenu.dataSource = self
        tblMenu.delegate = self
        tblMenu.scrollEnabled = false
        tblMenu.clipsToBounds = true
        tblMenu.backgroundColor = Color.cellBack
        tblMenu.separatorStyle = .None
        self.view.addSubview(tblMenu)
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return  arrMenu.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCellWithIdentifier("MenuCell\(indexPath.row)") as? LeftCell
        if cell == nil {
            cell = LeftCell(style: UITableViewCellStyle.Default, reuseIdentifier:("MenuCell\(indexPath.row)"))
            cell?.selectionStyle = .None
        }
        
        cell?.lblName.text = arrMenu[indexPath.row] as? String
        cell?.imgView.image = UIImage(named:(arrMenu[indexPath.row] as? String)!)
        return cell!
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.row == 5 {
            self.closeLeft()
            TCAlert.sharedInstance().show(alertTitle, message:"Are you sure do you want to logout ?", buttonsTitle:["Cancel","Ok"], willHideAlert: { (buttonIndex) -> Void in
                
                if buttonIndex == 1 {
                
                    NSUserDefaults.standardUserDefaults().removeObjectForKey("userInfro")
                    let appDel = UIApplication.sharedApplication().delegate as? AppDelegate
                    appDel!.nvController = UINavigationController(rootViewController:LoginViewController())
                    appDel!.nvController.navigationBarHidden = true
                    appDel!.window?.rootViewController = appDel!.nvController
                }
            })
        } else {
            
            var viewController:UIViewController!
            var navController:UINavigationController!
            viewController = HomeVC()
            if indexPath.row == 0 {
                viewController = HomeVC()
            }
            else if indexPath.row == 1 {//ContactListVC
                viewController = EditProfileVC()
            } else if indexPath.row == 2 {
                viewController = ContactListVC()
            }
            navController = UINavigationController(rootViewController:viewController)
            navController.navigationBarHidden = true
            self.slideMenuController()?.changeMainViewController(navController, close: true)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
