//
//  WebService.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/4/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import Foundation

let baseURL = "http://mjmobdev.com/call4help/"
let login = "login.php"
let signUp = "register.php"
let updateProfile = "updateProfile.php"