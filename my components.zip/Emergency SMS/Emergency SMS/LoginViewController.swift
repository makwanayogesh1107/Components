//
//  LoginViewController.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 4/29/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

var alertTitle = "Alert"


class LoginViewController: BaseViewController {

    var scrollView:TPKeyboardAvoidingScrollView!
    
    var txtEmail:TCTextField!
    var txtPassword:TCTextField!
    
    var btnRememberMe:UIButton!
    var lblRememberMe:UILabel!
    var btnForgotPassword:UIButton!
    
    var btnLogin:UIButton!
    
    var lblNewUser:UILabel!
    var btnSignUp:UIButton!
    
    var strAlertMessage:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        self.title = "Login"
        //ScrollView
        scrollView = TPKeyboardAvoidingScrollView(frame:TCRectMake(x: 0, y: 0, width: 320, height: 568))
        self.view.addSubview(scrollView)
        
        //Textbox Email
        txtEmail = TCTextField(frame:TCRectMake(x: 45,y: 150,width: 230,height: 45))
        txtEmail.setGUI("Email")
        txtEmail.autocapitalizationType = .None
        scrollView.addSubview(txtEmail)
        
        //Textbox Password
        txtPassword = TCTextField(frame:TCRectMake(x: 45,y: txtEmail.frame.relativeheight + txtEmail.frame.relativeY + 10,width: 230,height: 45))
        txtPassword.setGUI("Password")
        txtPassword.secureTextEntry = true
        scrollView.addSubview(txtPassword)
        
        //Remember me
        btnRememberMe = UIButton(frame: TCRectMake(x: 50, y: txtPassword.frame.relativeheight + txtPassword.frame.relativeY + 10, width: 22, height: 22));
        btnRememberMe.setImage(UIImage(named: "imgAgreeNotSelected"), forState: UIControlState.Normal)
        btnRememberMe.tag = 0
        btnRememberMe.addTarget(self, action: #selector(LoginViewController.tappedOnRememberMe(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        scrollView.addSubview(btnRememberMe)
        
        lblRememberMe = UILabel(frame: TCRectMake(x: 77, y: txtPassword.frame.relativeheight + txtPassword.frame.relativeY + 10, width: 100, height: 22))
        lblRememberMe.text = "Remember Me"
        lblRememberMe.textColor = Color.textColor
        lblRememberMe.font = Font(FontName.HelveticaNeue, size: 12)
        scrollView.addSubview(lblRememberMe)
        
        //Forgot Password
        btnForgotPassword = UIButton(frame: TCRectMake(x: 145, y: txtPassword.frame.relativeheight + txtPassword.frame.relativeY + 10, width: 150, height: 22))
        btnForgotPassword.setTitle("Forgot Password?", forState: .Normal)
        btnForgotPassword.setTitleColor(Color.themeRed, forState: .Normal)
        btnForgotPassword.setTitleColor(UIColor.whiteColor(), forState: .Highlighted)
        btnForgotPassword.titleLabel?.font = Font(FontName.HelveticaNeue, size: 12)
        btnForgotPassword.addTarget(self, action: Selector("tappedOnForgotPassword"), forControlEvents: UIControlEvents.TouchUpInside)
        scrollView.addSubview(btnForgotPassword)
        let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.StyleSingle.rawValue]
        let underlineAttributedForgotPass = NSAttributedString(string: "Forgot Password?", attributes: underlineAttribute)
        btnForgotPassword.titleLabel?.attributedText = underlineAttributedForgotPass
        
        //Login Button
        btnLogin = UIButton(frame:TCRectMake(x: 45,y: lblRememberMe.frame.relativeheight + lblRememberMe.frame.relativeY + 10,width: 230,height: 45))
        btnLogin.setTitle("Login", forState: UIControlState.Normal)
        btnLogin.addTarget(self, action: Selector("tappedOnLogin"), forControlEvents: UIControlEvents.TouchUpInside)
        btnLogin.layer.cornerRadius = 5
        btnLogin.titleLabel?.font = Font(FontName.HelveticaNeueBold, size: 14)
        btnLogin.backgroundColor = Color.themeRed
        btnLogin.setTitleColor(UIColor.grayColor(), forState: .Highlighted)
        scrollView.addSubview(btnLogin)
        
        //New user
        lblNewUser = UILabel(frame: TCRectMake(x: 90, y: btnLogin.frame.relativeheight + btnLogin.frame.relativeY + 10, width: 100, height: 22))
        lblNewUser.text = "New User?"
        lblNewUser.textColor = Color.textColor
        lblNewUser.font = Font(FontName.HelveticaNeue, size: 13)
        scrollView.addSubview(lblNewUser)
        
        //Sign up
        btnSignUp = UIButton(frame: TCRectMake(x: 150, y: btnLogin.frame.relativeheight + btnLogin.frame.relativeY + 10, width: 100, height: 22))
        btnSignUp.setTitle("Sign Up", forState: UIControlState.Normal)
        btnSignUp.setTitleColor(Color.themeRed, forState: .Normal)
        btnSignUp.titleLabel?.font = Font(FontName.HelveticaNeue, size: 13)
        btnSignUp.addTarget(self, action: Selector("tappedOnSignUp"), forControlEvents: UIControlEvents.TouchUpInside)
        let underlineAttributedSignUp = NSAttributedString(string: "Sign Up", attributes: underlineAttribute)
        btnSignUp.titleLabel?.attributedText = underlineAttributedSignUp
        scrollView.addSubview(btnSignUp)
        

    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     
    }
    override func leftButtonClick() {
        
    }
    func tappedOnRememberMe(sender:UIButton)
    {
        if sender.tag == 0
        {
            sender.setImage(UIImage(named: "imgAgreeSelected"), forState: UIControlState.Normal)
            sender.tag = 1
        }
        else
        {
            sender.setImage(UIImage(named: "imgAgreeNotSelected"), forState: UIControlState.Normal)
            sender.tag = 0
        }
    }
    func tappedOnLogin()
    {
        if isFormValid()
        {
            loginApi()
        }
        else
        {
            TCAlert().show(alertTitle, message:strAlertMessage, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
            })

        }
    }
    func isFormValid() ->Bool
    {
        
        if txtEmail.text?.isEmpty == true
        {
            strAlertMessage = "Please enter email."
            return false
        }
        else if isValidEmail(txtEmail.text!) == false
        {
            strAlertMessage = "Please enter valid email."
            return false
        }
        else if txtPassword.text?.isEmpty == true
        {
            strAlertMessage = "Please enter password."
            return false
        }
        else if isValidRange(8, maxNo: 16, strMessage: txtPassword.text!)
        {
            strAlertMessage = "Please enter password between 8 to 16 characters."
            return false
        }
        else
        {
            strAlertMessage = "Login successfully."
            return true
        }
    }
    func loginApi()
    {
        self.view.endEditing(true)
        Helper.sharedInstance.request.requestFor(requestURL:baseURL + login,
            type: .POST,
            parameters:[
                "email" : txtEmail.text!,
                "pwd" : txtPassword.text!
            ]).onProgress { (request, total, sent, type) -> () in
                        }.onSuccess { (request, response, error) -> () in
                            
            dispatch_async(dispatch_get_main_queue(),{
                if error != nil
                {
                    TCAlert.sharedInstance().show(alertTitle, message:(error?.localizedDescription)!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                        
                    })
                }
                else
                {
                    print(response)
                    if (response!["data"]!!["status"] as? NSNumber)?.integerValue == 1
                    {
                        if let userInfo = response!["data"] {
                            
                            if self.btnRememberMe.tag == 1 {
                                NSUserDefaults.standardUserDefaults().setObject(userInfo, forKey:"userInfro")
                            }
                            NSUserDefaults.standardUserDefaults().setObject(userInfo, forKey:"userInfro")
                            Helper.sharedInstance.dictUser = userInfo as! [String : AnyObject]
                            let appDel = UIApplication.sharedApplication().delegate as! AppDelegate
                            appDel.nvController = UINavigationController(rootViewController:HomeVC())
                            appDel.nvController.navigationBarHidden = true
                            let slideVC = ExSlideMenuController(mainViewController:appDel.nvController, leftMenuViewController:LeftSliderVC())
                            slideVC.automaticallyAdjustsScrollViewInsets = true
                            slideVC.closeLeft()
                            appDel.window?.backgroundColor = UIColor(red: 236.0, green: 238.0, blue: 241.0, alpha: 1.0)
                            appDel.window?.rootViewController = slideVC
                        }
                    }
                    else
                    {
                        let errorMsg = response!["data"]!!["msg"] as? String
                        TCAlert.sharedInstance().show(alertTitle, message:errorMsg!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                        })
                    }
                }
            })
        }

    }
    func gotoHome()
    {
        
    }
    func tappedOnForgotPassword()
    {
        self.navigationController?.pushViewController(ForgotPasswordVC(), animated: true)
    }
    func tappedOnSignUp()
    {
        self.navigationController?.pushViewController(SignupVC(), animated:true)
    }
}
extension TCTextField {
    func setGUI(txtPlace:String,backColor:UIColor = UIColor(white:95, alpha: 1),raduis:CGFloat = 5) {
        self.placeholder = txtPlace
        self.backgroundColor = backColor
        self.layer.cornerRadius = raduis
        self.setPadding(15, right: 15)
        self.layer.borderWidth = 1
        self.layer.borderColor = Color.lightDark.CGColor
        
    }
    
}
