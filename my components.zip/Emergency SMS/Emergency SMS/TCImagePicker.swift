

import UIKit

import UIKit
import AVFoundation
import MobileCoreServices
import ImageIO
import AssetsLibrary

//================================================ TCImagePicker ======================================================

class TCImagePicker:NSObject,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UIActionSheetDelegate
{
    static var useFrontCamera=false
    static var allowImageEdting=false
    static var isSaveToLibrary=false
    static var videoQuality=UIImagePickerControllerQualityType.TypeMedium
    
    private var isPickupVideo=false
    private var isCamera=false
    
    //private var successHandler:((Bool,UIImage,UIImage)->Void)!
    //private var videoSuccessHandler:((Bool,UIImage,NSURL,NSData)->Void)!
    
    private var failureHandler:((String)->(Void)?)!
    private var completeHandler:((Bool,[TCAsset])->Void)!
    private var isMultiple:Bool!
    private var assertType:ALAssetsFilter!
    
    static var instance: TCImagePicker!
    class func sharedInstance() -> TCImagePicker
    {
        self.instance = (self.instance ?? TCImagePicker())
        return self.instance
    }
    override init()
    {
        super.init()
    }
    
    deinit
    {
        print("Object distroyed")
    }
    func openImagePicker(
        actionSheetTitle:String="Choose",
        cancelTitle:String="Cancel",
        cameraTitle:String="Camera",
        galleryTitle:String="Gallery",
        isImage:Bool=true,
        isMultipleSelection:Bool=false,
        completeHandler:(success:Bool,arrAssert:[TCAsset])->Void,
        failurer:((error:String)->(Void))?=nil)
    {
        
        let actionSheet=UIActionSheet(title: actionSheetTitle, delegate:self, cancelButtonTitle:cancelTitle, destructiveButtonTitle:nil,otherButtonTitles: cameraTitle,galleryTitle)
        
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone
        {
            actionSheet.showInView(UIApplication.sharedApplication().keyWindow!)
        }
        else
        {
            let appDel = UIApplication.sharedApplication().delegate as? AppDelegate
            
            
            actionSheet.showInView((appDel?.window?.rootViewController?.view)!)
        }
        
        
        
        
        self.isMultiple=isMultipleSelection
        self.completeHandler=completeHandler
        self.failureHandler=failurer
        if isImage==true
        {
            self.isPickupVideo=false
            self.assertType=ALAssetsFilter.allPhotos()
        }
        else
        {
            self.isPickupVideo=true
            self.assertType=ALAssetsFilter.allVideos()
        }
    }
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int)
    {
        if buttonIndex==1
        {
            if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera))
            {
                isCamera=true
                openCamera()
            }
            else
            {
                UIAlertView(title:"Alert", message:"Camera not Available.", delegate:nil, cancelButtonTitle:"Ok").show()
            }
            
        }
        else if buttonIndex==2
        {
            if self.isMultiple==true || self.isPickupVideo==true
            {
                self.openMultiplePicker()
            }
            else
            {
                self.openSinglePicker()
            }
        }
    }
    private func openMultiplePicker()
    {
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        let screenWidth = screenSize.width
        let thisWidth = screenWidth - 10
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top:10, left: 10, bottom: 10, right: 10)
        layout.itemSize = CGSize(width: thisWidth, height: 120)
        
        
        let collectionView=TCImagePickerCollection(collectionViewLayout:layout)
        collectionView.successHandler=self.completeHandler
        collectionView.failureHandler=self.failureHandler
        collectionView.assertType=self.assertType
        collectionView.isMultiple=self.isMultiple
        
        let navController=UINavigationController(rootViewController:collectionView )
        let controller=(UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController
        
        dispatch_async(dispatch_get_main_queue()) { [unowned self] in
           controller?.presentViewController(navController, animated:true, completion:nil)
        }
        
    }
    private func openSinglePicker()
    {
        let cameraPicker=UIImagePickerController()
        cameraPicker.delegate=self
        cameraPicker.allowsEditing=TCImagePicker.allowImageEdting
        cameraPicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        cameraPicker.mediaTypes = [kUTTypeImage as String]
        if self.isPickupVideo==true
        {
            cameraPicker.mediaTypes = [kUTTypeMovie as String]
            cameraPicker.videoQuality=TCImagePicker.videoQuality
        }
        let controller=(UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController
        
        dispatch_async(dispatch_get_main_queue()) { [unowned self] in
        controller?.presentViewController(cameraPicker, animated:true, completion:nil)
        }
    }
    private func openCamera()
    {
        let cameraPicker=UIImagePickerController()
        cameraPicker.delegate=self
        cameraPicker.allowsEditing=TCImagePicker.allowImageEdting
        cameraPicker.sourceType = UIImagePickerControllerSourceType.Camera
        cameraPicker.cameraDevice=UIImagePickerControllerCameraDevice.Rear
        cameraPicker.mediaTypes = [kUTTypeImage as String]
        if self.isPickupVideo==true
        {
            cameraPicker.mediaTypes = [kUTTypeMovie as String]
            cameraPicker.videoQuality=TCImagePicker.videoQuality
        }
        if TCImagePicker.useFrontCamera==true
        {
            cameraPicker.cameraDevice=UIImagePickerControllerCameraDevice.Front
        }
        
        let controller=(UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController
        
        dispatch_async(dispatch_get_main_queue()) { [unowned self] in
            controller?.presentViewController(cameraPicker, animated:true, completion:nil)
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        if self.isPickupVideo==true
        {
            let urlVideo=info[UIImagePickerControllerMediaURL] as! NSURL
            let thumbnailImage=self.createThubnailImage(urlVideo)
            completeHandler(true,[TCAsset(image:thumbnailImage, videoURL: urlVideo)])
            
        }
        else
        {
            let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            if isCamera==true && TCImagePicker.isSaveToLibrary==true
            {
                self.saveToLilrary(selectedImage)
            }
            if let editedImage = info[UIImagePickerControllerEditedImage] as? UIImage
            {
                let assert = TCAsset(image:editedImage)
                assert.fullResolutionImage=selectedImage
                assert.fullScreenImage=selectedImage
                completeHandler(true,[assert])
            }
            else
            {
                completeHandler(true,[TCAsset(image:selectedImage)])
            }
            
        }
        picker.dismissViewControllerAnimated(true, completion:nil)
        TCImagePicker.instance=nil
    }
    func saveToLilrary(image:UIImage)
    {
        UIImageWriteToSavedPhotosAlbum(image,nil, "image:didFinishSavingWithError:contextInfo:", nil)
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        if failureHandler != nil
        {
            if self.isPickupVideo==true
            {
                failureHandler("video pickup operation cancel")
            }
            else
            {
                failureHandler("image pickup operation cancel")
            }
        }
        picker.dismissViewControllerAnimated(true, completion:nil)
        TCImagePicker.instance=nil
    }
    func imageResize(imageObj:UIImage, sizeChange:CGSize)-> UIImage {
        
        let hasAlpha = false
        let scale: CGFloat = 0.0
        UIGraphicsBeginImageContextWithOptions(sizeChange, !hasAlpha, scale)
        imageObj.drawInRect(CGRect(origin: CGPointZero, size: sizeChange))
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        //saveImageIntoDocument(scaledImage)
        return scaledImage
    }
//    func saveImageIntoDocument(resizeImage:UIImage,saveCompleted:((String)->())? = nil)
//    {
//        let documentsUrl =  NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
//        
//        let filePath = documentsUrl.relativePath!.stringByAppendingString("/\(timeStamp)")
//        if saveCompleted != nil
//        {
//            saveCompleted!(timeStamp)
//        }
//        UIImagePNGRepresentation(resizeImage)!.writeToFile(filePath, atomically: true)
//    
//    }
    func createThubnailImage(urlPath:NSURL)->UIImage
    {
        let asset=AVURLAsset(URL:urlPath)
        var image:UIImage?
        let imgGenerator=AVAssetImageGenerator(asset:asset )
        do
        {
            let cgImage = try imgGenerator.copyCGImageAtTime(CMTimeMake(0, 1), actualTime: nil)
            if self.isCamera==true
            {
                image=UIImage(CGImage:cgImage, scale:1, orientation:UIImageOrientation.Right)
            }
            else
            {
                image = UIImage(CGImage:cgImage, scale:1, orientation:UIImageOrientation.Up)
            }
        }
        catch{}
        return image!
    }
    func changeImageOrientation(originalImage:UIImage,orientation:UIImageOrientation)->UIImage
    {
        let ciImage=CIImage(image:originalImage)
        return UIImage(CIImage:ciImage!, scale:1, orientation:orientation)
    }
    
}

//================================================ TCImagePickerCollection ======================================================
/*
TCImagePickerCollection is for multiple selection
*/

class TCImagePickerCollection:UICollectionViewController,UICollectionViewDelegateFlowLayout
{
    //private let sectionInsets = UIEdgeInsets(top: 0, left:0, bottom: 0, right:0)
    private var groups = [TCAssetGroup]()
    internal var selectedAssetGroup=TCAssetGroup()
    private var arrSelectedAssert=[TCAsset]()
    
    static private let library = ALAssetsLibrary()
    internal var assetGroupTypes: UInt32 = ALAssetsGroupAll
    
    var failureHandler:((String)->(Void)?)!
    var successHandler:((Bool,[TCAsset])->Void)!
    var assertType:ALAssetsFilter!
    var isMultiple:Bool!
    
    override init(collectionViewLayout layout: UICollectionViewLayout)
    {
        super.init(collectionViewLayout:layout)
        
        self.collectionView?.backgroundColor=UIColor.whiteColor()
    }
    override func viewDidLoad()
    {
        self.navigationController?.navigationBarHidden=false
        self.view.backgroundColor=UIColor.whiteColor()
        self.navigationItem.rightBarButtonItem=UIBarButtonItem(title:"Done", style: UIBarButtonItemStyle.Done, target:self, action:"dismissController")
        
        self.loadAssetGroupsThen { (error) -> () in
            if let firstGroup = self.groups.first
            {
                self.selectAssetGroup(firstGroup)
            }
        }
        
        
    }
    func dismissController()
    {
        
        if arrSelectedAssert.count==0 && failureHandler != nil
        {
            failureHandler("no items selected")
        }
        else
        {
            successHandler(true,arrSelectedAssert)
        }
        self.dismissViewControllerAnimated(true, completion:nil)
        TCImagePicker.instance=nil
    }
    func selectAssetGroup(assetGroup: TCAssetGroup)
    {
        /*if self.selectedAssetGroup == assetGroup
        {
        return
        }*/
        self.selectedAssetGroup = assetGroup
        self.title = "Selected(0)"
        self.collectionView!.reloadData()
    }
    override func viewWillAppear(animated: Bool) {
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int
    {
        return self.groups.count
    }
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return (self.groups[section] as TCAssetGroup).totalCount
    }
    
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        let identifier="ImageCell\(indexPath.section)\(indexPath.row)"
        collectionView.registerClass(ImageViewCell.self, forCellWithReuseIdentifier:identifier)
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as! ImageViewCell
        cell.backgroundColor = UIColor.darkGrayColor()
        self.groups[indexPath.section].group.enumerateAssetsAtIndexes(NSIndexSet(index:indexPath.row), options: .Reverse,
            usingBlock: { (result, index, stop) -> Void in
                if result != nil
                {
                    let asset = TCAsset(originalAsset: result)
                    cell.imgView.image=asset.thumbnailImage
                    
                    if asset.isVideo==true
                    {
                        cell.viewVideo.hidden=false
                        let sec=Int(asset.duration!%60)
                        let min=Int(asset.duration!/60)
                        cell.lblVideoTime.text="\(min):\(sec)"
                    }
                    else
                    {
                        cell.viewVideo.hidden=true
                    }
                }
        })
        return cell
    }
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        let width=UIScreen.mainScreen().bounds.size.width-50
        return CGSize(width:width/3, height:width/3)
    }
    
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath)
    {
        
        let cell=collectionView.cellForItemAtIndexPath(indexPath) as! ImageViewCell
        
        
        
        if cell.imgSelectView.hidden
        {
            if self.arrSelectedAssert.count <= 3
            {
            self.groups[indexPath.section].group.enumerateAssetsAtIndexes(NSIndexSet(index:indexPath.row), options: .Reverse,
                usingBlock: { (result, index, stop) -> Void in
                    if result != nil
                    {
                        let asset = TCAsset(originalAsset: result)
                        self.arrSelectedAssert.append(asset)
                        self.title = "Selected(\(self.arrSelectedAssert.count))"
                        if self.isMultiple==false
                        {
                            self.dismissController()
                        }
                    }
            })
            cell.imgSelectView.backgroundColor=UIColor(red:0, green: 0, blue: 0, alpha:0.5)
            }
            
        }
        else
        {
            self.groups[indexPath.section].group.enumerateAssetsAtIndexes(NSIndexSet(index:indexPath.row), options: .Reverse,
                usingBlock: { (result, index, stop) -> Void in
                    if result != nil
                    {
                        let asset = TCAsset(originalAsset: result)
                        self.arrSelectedAssert.removeAtIndex(self.arrSelectedAssert.indexOf(asset)!)
                        self.title = "Selected(\(self.arrSelectedAssert.count))"
                    }
            })
            cell.imgSelectView.backgroundColor=UIColor.clearColor()
        }
        if self.arrSelectedAssert.count <= 3
        {
            cell.imgSelectView.hidden = !cell.imgSelectView.hidden
        }else
        {
            
            arrSelectedAssert.removeLast()
            self.title = "Selected(\(self.arrSelectedAssert.count))"
        }
    }
    
    func loadAssetGroupsThen(block: ((error: NSError?) -> ())) {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) { () -> Void in
            
            self.dynamicType.library.enumerateGroupsWithTypes(self.assetGroupTypes, usingBlock: { [weak self] (group, stop) in
                
                if group != nil
                {
                    group.setAssetsFilter(self!.assertType)
                    
                    if group.numberOfAssets() != 0
                    {
                        let groupName = group.valueForProperty(ALAssetsGroupPropertyName) as! String
                        
                        let assetGroup = TCAssetGroup()
                        assetGroup.groupName = groupName
                        
                        group.enumerateAssetsAtIndexes(NSIndexSet(index: group.numberOfAssets() - 1),
                            options: .Reverse,
                            usingBlock: { (asset, index, stop) -> Void in
                                if asset != nil {
                                    assetGroup.thumbnail = UIImage(CGImage:asset.thumbnail().takeUnretainedValue())
                                }
                        })
                        assetGroup.group = group
                        assetGroup.totalCount = group.numberOfAssets()
                        self!.groups.insert(assetGroup, atIndex: 0)
                    }
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        block(error: nil)
                        
                    })
                    
                    /*dispatch_async(dispatch_get_main_queue(), { [weak self] () -> Void in
                    block(error: nil)
                    
                    })*/
                }
                }, failureBlock: {(error) in
                    dispatch_async(dispatch_get_main_queue(), { [weak self]() -> Void in
                        guard let strongSelf = self else { return }
                        strongSelf.collectionView?.hidden = true
                        block(error: error)
                        })
            })
        }
    }
    
    
}

//================================================ ImageViewCell ======================================================

class ImageViewCell: UICollectionViewCell
{
    
    var imgView:UIImageView!
    var imgSelectView:UIImageView!
    var btnVideo:UIButton!
    var viewVideo:UIView!
    var lblVideoTime:UILabel!
    override func awakeFromNib()
    {
        
    }
    override func prepareForReuse()
    {
        super.prepareForReuse()
    }
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        
        
        let width=frame.size.width
        
        imgView=UIImageView(frame:CGRectMake(0,0,width,width))
        imgView.clipsToBounds=true
        imgView.backgroundColor=UIColor.lightGrayColor()
        imgView.contentMode=UIViewContentMode.ScaleAspectFill
        self.contentView.addSubview(imgView)
        
        imgSelectView=UIImageView(frame:CGRectMake(0,0,width,width))
        imgSelectView.contentMode=UIViewContentMode.Center
        imgSelectView.image=UIImage(named:"tick_blue")
        imgSelectView.backgroundColor=UIColor.clearColor()
        imgSelectView.hidden=true
        self.contentView.addSubview(imgSelectView)
        
        viewVideo=UIView(frame:CGRectMake(0,frame.size.height-25,width,25))
        viewVideo.backgroundColor=UIColor(red:0, green: 0, blue: 0, alpha:0.5)
        viewVideo.hidden=true
        self.contentView.addSubview(viewVideo)
        
        let imgVideoIcon=UIImageView(frame:CGRectMake(5,5,26,15))
        imgSelectView.contentMode=UIViewContentMode.Center
        imgVideoIcon.image=UIImage(named:"video_camera")
        viewVideo.addSubview(imgVideoIcon)
        
        lblVideoTime=UILabel(frame:CGRectMake((width/2)-5,0,width/2,25))
        lblVideoTime.textAlignment=NSTextAlignment.Right
        lblVideoTime.textColor=UIColor.whiteColor()
        lblVideoTime.font=UIFont(name:"Helvetica", size:13)
        viewVideo.addSubview(lblVideoTime)
        
    }
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//================================================ TCAssetGroup ======================================================

internal class TCAssetGroup : NSObject
{
    var groupName: String!
    var thumbnail: UIImage!
    var totalCount=0
    var group: ALAssetsGroup!
}

//================================================ TCAsset ======================================================

public class TCAsset: NSObject
{
    
    /// Returns a CGImage of the representation that is appropriate for displaying full screen.
    public private(set) lazy var fullScreenImage: UIImage? = {
        if let originalAsset = self.originalAsset {
            return UIImage(CGImage: (originalAsset.defaultRepresentation().fullScreenImage().takeUnretainedValue()))
        }
        return nil
    }()
    
    /// Returns a CGImage representation of the asset.
    public private(set) lazy var fullResolutionImage: UIImage? = {
        if let originalAsset = self.originalAsset {
            return UIImage(CGImage: (originalAsset.defaultRepresentation().fullResolutionImage().takeUnretainedValue()))
        }
        return nil
    }()
    
    /// The url uniquely identifies an asset that is an image or a video.
    public private(set) var url: NSURL?
    
    /// It's a square thumbnail of the asset.
    public private(set) var thumbnailImage: UIImage?
    
    /// The asset's creation date.
    public private(set) lazy var createDate: NSDate? = {
        if let originalAsset = self.originalAsset {
            return originalAsset.valueForProperty(ALAssetPropertyDate) as? NSDate
        }
        return nil
    }()
    
    /// When the asset was an image, it's false. Otherwise true.
    public private(set) var isVideo: Bool = false
    
    /// play time duration(seconds) of a video.
    public private(set) var duration: Double?
    
    internal var isFromCamera: Bool = false
    public private(set) var originalAsset: ALAsset?
    
    /// The source data of the asset.
    public private(set) lazy var rawData: NSData? = {
        if let rep = self.originalAsset?.defaultRepresentation() {
            let sizeOfRawDataInBytes = Int(rep.size())
            let rawData = NSMutableData(length: sizeOfRawDataInBytes)!
            let bufferPtr = rawData.mutableBytes
            let bufferPtr8 = UnsafeMutablePointer<UInt8>(bufferPtr)
            
            rep.getBytes(bufferPtr8, fromOffset: 0, length: sizeOfRawDataInBytes, error: nil)
            return rawData
        }
        return nil
    }()
    
    internal init(originalAsset: ALAsset) {
        super.init()
        
        self.thumbnailImage = UIImage(CGImage:originalAsset.aspectRatioThumbnail().takeUnretainedValue())
        self.url = originalAsset.valueForProperty(ALAssetPropertyAssetURL) as? NSURL
        self.originalAsset = originalAsset
        
        let assetType = originalAsset.valueForProperty(ALAssetPropertyType) as! NSString
        if assetType == ALAssetTypeVideo {
            let duration = originalAsset.valueForProperty(ALAssetPropertyDuration) as! NSNumber
            
            self.isVideo = true
            self.duration = duration.doubleValue
        }
    }
    
    internal init(image: UIImage) {
        super.init()
        
        self.isFromCamera = true
        self.fullScreenImage = image
        self.fullResolutionImage = image
        self.thumbnailImage = image
    }
    internal init(image: UIImage,videoURL:NSURL)
    {
        super.init()
        self.isFromCamera = true
        self.fullScreenImage = image
        self.fullResolutionImage = image
        self.thumbnailImage = image
        self.url=videoURL
        self.rawData=NSData(contentsOfURL:self.url!)
    }
    
    // Compare two TCAssets
    override public func isEqual(object: AnyObject?) -> Bool {
        let another = object as! TCAsset!
        
        if let url = self.url, anotherUrl = another.url {
            return url.isEqual(anotherUrl)
        } else {
            return false
        }
    }
}
