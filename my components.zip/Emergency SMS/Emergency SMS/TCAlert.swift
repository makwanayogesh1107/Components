

import UIKit

class TCAlert:NSObject,UIAlertViewDelegate
{
    var alert:UIAlertView!
    var duration=Double(5)
    private var isAutoHide=Bool(false)
    private var hasTextfeild=Bool(false)
    
    var willHideAlert:((Int)->(Void)?)!
    var willHideWithSingleText:((Int,String)->Void)!
    var willHideWithValue:([String]->Void)!
    
    static var instance: TCAlert!
    class func sharedInstance() -> TCAlert
    {
        self.instance = (self.instance ?? TCAlert())
        return self.instance
    }

    
    func show(
        title: String?=nil,
        message: String="",
        buttonsTitle:[String]=[],
        willHideAlert:((buttonIndex:Int)->Void)?=nil)
    {
        
        self.willHideAlert=willHideAlert
        if #available(iOS 8.0, *)
        {
            let alertController = UIAlertController(title:title, message:message, preferredStyle: .Alert)
            
            for strTitle in buttonsTitle
            {
                let action = UIAlertAction(title:strTitle, style: .Default, handler: { (UIAlertAction) -> Void in
                    self.willHideAlert(buttonsTitle.indexOf(UIAlertAction.title!)!)
                })
                alertController.addAction(action)
            }
            let controller=(UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController
            
            
            dispatch_async(dispatch_get_main_queue()) { [unowned self] in
            controller?.presentViewController(alertController, animated:true, completion:nil)
            }

            
            
            if buttonsTitle.count==0
            {
                self.isAutoHide=true
                self.willHideAlert=willHideAlert
                let delay = self.duration * Double(NSEC_PER_SEC)
                let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
                dispatch_after(time, dispatch_get_main_queue(), {
                    if self.willHideAlert != nil
                    {
                        self.willHideAlert(-1)
                    }
                    alertController.dismissViewControllerAnimated(true, completion:nil)
                })
            }
        }
        else
        {
            UIAlertView(title:"Warnging", message:"TCAlert support only on iOS 8 onworld", delegate:nil, cancelButtonTitle:"Ok").show()
            self.alertWithOkButton(title!, message:message, buttonTitle:buttonsTitle[0], willHideAlert:willHideAlert!)
            
        }
    }
    func alertWithOkButton(title:String, message:String,buttonTitle:String,willHideAlert:(buttonIndex:Int)->Void)
    {
        self.willHideAlert=willHideAlert
        UIAlertView(title:title, message:message, delegate:self, cancelButtonTitle:buttonTitle).show()
    }
    func alertView(alertView: UIAlertView, willDismissWithButtonIndex buttonIndex: Int)
    {
        if alertView.tag==100 && self.willHideWithSingleText != nil
        {
            self.willHideWithSingleText(buttonIndex,(alertView.textFieldAtIndex(0)?.text)!)
        }
        else if self.willHideAlert != nil
        {
            self.willHideAlert(buttonIndex)
        }
        TCAlert.instance=nil
    }

    
    func showWithTextField(title: String?=nil,
        message: String="",
        okTitle:String?="Ok",
        cancelTitle:String?=nil,
        textFields:[String]=[],
        arrIsSecureAtIndext:Dictionary<Int,Bool>,
        willHideWithValue:((arrTxtValues:[String])->Void))
    {
        
        self.willHideWithValue=willHideWithValue
        var arrtextField=[UITextField]()
        if #available(iOS 8.0, *)
        {
            let alertController = UIAlertController(title:title, message:message, preferredStyle: .Alert)
            
            var count=0
            for strTitle in textFields
            {
                alertController.addTextFieldWithConfigurationHandler({ (textField) -> Void in
                    if let issecure=arrIsSecureAtIndext[count]
                    {
                        textField.secureTextEntry=issecure
                    }
                    textField.placeholder=strTitle
                    arrtextField.append(textField)
                    count++
                })
            }
            if cancelTitle != nil
            {
                let action = UIAlertAction(title:cancelTitle, style: .Default, handler: { (UIAlertAction) -> Void in
                })
                alertController.addAction(action)
            }
            
            if okTitle != nil
            {
                let action = UIAlertAction(title:okTitle, style: .Default, handler: { (UIAlertAction) -> Void in
                    
                    var arrValue=[String]()
                    for text in alertController.textFields!
                    {
                        arrValue.append(text.text!)
                    }
                    self.willHideWithValue(arrValue)
                })
                alertController.addAction(action)
            }
            let controller=(UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController
            
            dispatch_async(dispatch_get_main_queue()) { [unowned self] in
                controller?.presentViewController(alertController, animated:true, completion:nil)
            }
            
        }
        else
        {
            UIAlertView(title:"Warnging", message:"TCAlert support only on iOS 8 onworld", delegate:nil, cancelButtonTitle:"Ok").show()
        }

    }
}
