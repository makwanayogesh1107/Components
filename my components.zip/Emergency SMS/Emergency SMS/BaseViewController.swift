//
//  BaseViewController.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 4/30/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

struct Screen {
    static var width = UIScreen.mainScreen().bounds.size.width
    static var height = UIScreen.mainScreen().bounds.size.height
}

class BaseViewController: UIViewController
{

    var viewHeader:UIView!
    var btnLeft:UIButton!
    var lblTitle : UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = Color.screenBack
        
        viewHeader = UIView(frame:CGRectMake(0,0,Screen.width,64))
        viewHeader.backgroundColor = Color.themeRed
        self.view.addSubview(viewHeader)
        
            
        lblTitle = UILabel(frame: CGRectMake(50, 25, Screen.width - 100, 30))
        lblTitle.textColor = UIColor(white:95, alpha: 1)
        lblTitle.font = Font(FontName.HelveticaNeueBold, size: 16)
        lblTitle.textAlignment = .Center
        self.viewHeader.addSubview(lblTitle)
        
        btnLeft = UIButton(type: UIButtonType.Custom)
        btnLeft.frame = CGRectMake(5,20,35,35)
        btnLeft.setImage(UIImage(named:"btn_back"), forState: UIControlState.Normal)
        btnLeft.addTarget(self, action: Selector("leftButtonClick"), forControlEvents: UIControlEvents.TouchUpInside)
        self.viewHeader.addSubview(btnLeft)
        
        
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        lblTitle.text = title
        view.bringSubviewToFront(viewHeader)
        
        if self.navigationController?.viewControllers.count == 1
        {
            btnLeft.hidden = true
        }
        else
        {
            btnLeft.hidden = false
        }
    }
    override func preferredStatusBarStyle() -> UIStatusBarStyle
    {
        return UIStatusBarStyle.LightContent
    }

    func leftButtonClick()
    {
        self.navigationController?.popViewControllerAnimated(true)
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
}
