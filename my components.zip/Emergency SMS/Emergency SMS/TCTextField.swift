

import UIKit

enum InputType {
    case alphanumeric
    case alphabates
    case decimal
    case phone
    case number
    case email
    case datePicker(mode:UIDatePickerMode,minuteInterval:Int ,displayFormat:String)
    case picker(data:[AnyObject])
    case list(data:[AnyObject],multipleSelection:Bool,displayKey:String?)
}

class TCTextField:UITextField {
    
    private static var themeFont:UIFont?
    private static var themeFontSize:CGFloat?
    private static var themeFontColor:UIColor?
    private static var themePlaceholderFont:UIFont?
    private static var themePlaceholderColor:UIColor?
    private static var themeBackgroundColor:UIColor = UIColor.clearColor()
    private static var themeBorderWidth:CGFloat = 0.0
    private static var themeBorderColor:CGColor = UIColor.blackColor().CGColor
    private static var themeCornerRadius:CGFloat = 0.0
    private static var themeLeftPadding:CGFloat = 5.0
    private static var themeRightPadding:CGFloat = 5.0
    
    private let screenWidth = UIScreen.mainScreen().bounds.size.width
    private let screenHeight = UIScreen.mainScreen().bounds.size.height
    
    private var datePicker: UIDatePicker?
    private var dateFormate: String?
    
    private var picker: UIPickerView?
    private var pickerColumn: Int = 0
    private var pickerArray = []
    
    var tblList: UITableView?
    private var listArray = []
    private var selectedListArray = NSMutableArray()
    private var isMultiSelection = true
    private var disPlayKey: String?
    
    func setTypeArributes(linesSpace:CGFloat,charSapce:CGFloat,font:UIFont,fontColor:UIColor) {
        let paraStyle = NSMutableParagraphStyle()
        paraStyle.lineSpacing = linesSpace
        self.defaultTextAttributes = [NSParagraphStyleAttributeName : paraStyle, NSKernAttributeName : charSapce, NSForegroundColorAttributeName : fontColor, NSFontAttributeName : font]
    }
    
    class func setThemeFontWith(name:String,size:CGFloat,color:UIColor = UIColor.blackColor()) {
        self.themeFont = UIFont(name: name, size: size)!
        self.themeFontColor = color
        self.themeFontSize = size
    }
    
    class func setThemePlaceholderFont(name:String,size:CGFloat, color:UIColor = UIColor.lightGrayColor()) {
        self.themePlaceholderFont = UIFont(name: name, size: size)!
        self.themePlaceholderColor = color
    }
    
    class func setThemeBorder(width:CGFloat,color:CGColor,corner:CGFloat = 0.0) {
        self.themeBorderWidth = width
        self.themeBorderColor = color
        self.themeCornerRadius = corner
    }
    
    class func setThemeLeftPadding(letfPadding:CGFloat = 5.0,rightPadding:CGFloat = 5.0) {
        themeLeftPadding = letfPadding
        themeRightPadding = rightPadding
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        if let color = TCTextField.themeFontColor {
            self.textColor = color
        }
        
        if let font = TCTextField.themeFont {
            self.font = font
        }
        self.backgroundColor = TCTextField.themeBackgroundColor
        self.contentVerticalAlignment = .Center
        self.leftPadding = TCTextField.themeLeftPadding
        self.rightPadding = TCTextField.themeRightPadding
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func setFontWith(name:String,size:CGFloat,color:UIColor = UIColor.blackColor()) {
        self.font = UIFont(name: name, size: size)!
        self.textColor = color
    }
    
    func setBorder(width:CGFloat = 0.0,color:CGColor = UIColor.blackColor().CGColor,corner:CGFloat = 0.0) {
        self.layer.borderWidth = width
        self.layer.borderColor = color
        self.layer.cornerRadius = corner
    }
    
    func setPlaceholder(placeholder:String,color:UIColor? = nil,font:UIFont? = nil) {
        if color != nil || font != nil {
            self.attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [NSForegroundColorAttributeName : color ?? UIColor.lightGrayColor(), NSFontAttributeName : font ?? UIFont.systemFontOfSize(UIFont.systemFontSize())])
        } else if TCTextField.themePlaceholderColor != nil || TCTextField.themePlaceholderFont != nil {
            self.attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [NSForegroundColorAttributeName : TCTextField.themePlaceholderColor ?? UIColor.lightGrayColor(), NSFontAttributeName : TCTextField.themePlaceholderFont ?? UIFont.systemFontOfSize(UIFont.systemFontSize())])
        } else {
            self.placeholder = placeholder
        }
    }
    
    var inputType:InputType? {
        didSet {
            
            switch (inputType!) {
            case .alphanumeric:
                self.keyboardType = UIKeyboardType.Alphabet
            case .alphabates:
                self.keyboardType = UIKeyboardType.Alphabet
            case .decimal:
                self.keyboardType = UIKeyboardType.DecimalPad
            case .phone:
                self.keyboardType = UIKeyboardType.PhonePad
            case .number:
                self.keyboardType = UIKeyboardType.NumberPad
            case .email:
                self.keyboardType = UIKeyboardType.EmailAddress
            case .datePicker(let mode,let minuteInterval,let displayFormat):
                self.setInputHeaderWith(nil, textColor: UIColor.whiteColor(), doneBlock: { (textField) -> () in
                    
                    }, nextBlock: nil, prevBlock: nil)
                self.setInputTypeDate(mode, minuteInterval: minuteInterval,dateDisplayFormat: displayFormat)
            case .picker(let data):
                self.setInputHeaderWith(nil, textColor: UIColor.whiteColor(), doneBlock: { (textField) -> () in
                    
                    }, nextBlock: nil, prevBlock: nil)
                self.setInputTypePicker(data)
            case .list(let data,let multipleSelection,let displayKey):
                self.setInputHeaderWith(nil, textColor: UIColor.whiteColor(), doneBlock: { (textField) -> () in
                    
                    }, nextBlock: nil, prevBlock: nil)
                self.setInputTypeListWithDic(data, strDisplayKey: displayKey, isMultiSelect: multipleSelection)
            }
            
        }
    }
    
    
    private func setInputTypeDate(mode:UIDatePickerMode, minuteInterval:Int = 1, dateDisplayFormat:String){
        if datePicker == nil{
            dateFormate = dateDisplayFormat
            datePicker = UIDatePicker(frame: CGRectMake(0, 0, screenWidth, 200))
            datePicker?.backgroundColor = UIColor.whiteColor()
            datePicker?.datePickerMode = mode
            datePicker?.minuteInterval = minuteInterval
            self.inputView = datePicker
        }
    }
    
    private func setDateInDatePicker(date: NSDate?){
        if(datePicker != nil){
            datePicker?.minimumDate = (NSDate().compare(date!) == NSComparisonResult.OrderedAscending ? NSDate() : date)
            datePicker!.date = (date == nil ? NSDate() : date!)
            if date != nil && dateFormate!.isEmpty == false{
                let dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = dateFormate
                self.text = dateFormatter.stringFromDate(date!)
            }
        }
    }
    
    // picker data type
    
    func setInputTypePicker(arrData: [AnyObject], withDicDisplayKey: String? = nil){
        disPlayKey = withDicDisplayKey
        if picker == nil {
            if arrData.count > 0{
                pickerArray = arrData
                pickerColumn = (arrData[0].isKindOfClass(NSArray.self) ? arrData.count : 1)
                picker = UIPickerView(frame: CGRectMake(0, 0, screenWidth, 173))
                picker?.backgroundColor = UIColor.whiteColor()
                picker?.delegate = self
                picker?.dataSource = self
                self.inputView = picker
            }
        }
    }
    
    func setSelectedPickerValue(selectedValue: String){
        if selectedValue.isEmpty == false{
            self.text = selectedValue
            var row : Int = 0
            if(disPlayKey?.isEmpty == false){
                for value in pickerArray{
                    if(value.valueForKey(disPlayKey!) as? String == selectedValue){
                        picker?.selectRow(row, inComponent: 0, animated: true)
                    }
                    row++
                }
            }else if pickerColumn == 1{
                for value in pickerArray{
                    if value as? String == selectedValue{
                        picker?.selectRow(row, inComponent: 0, animated: true)
                        break
                    }
                    row++
                }
            }else{
                var selectedValueArray = selectedValue .componentsSeparatedByString(", ")
                for var column = 0; column < pickerColumn; column++ {
                    row = 0
                    for value in pickerArray[column] as! NSArray{
                        if value as? String == selectedValueArray[column]{
                            picker?.selectRow(row, inComponent: column, animated: true)
                            break
                        }
                        row++
                    }
                }
            }
        }
    }
    
    func setInputTypeListWithDic(array: [AnyObject]?, strDisplayKey: String?, isMultiSelect: Bool = false){
        disPlayKey = strDisplayKey
        setInputTypeList(array, isMultiSelect: isMultiSelect)
    }
    
    func setInputTypeList(array: [AnyObject]?, isMultiSelect: Bool = false){
        isMultiSelection = isMultiSelect
        if(tblList == nil){
            listArray = array!
            
            if (array?.count)! * 44 < Int(screenHeight - 44) {
                tblList = UITableView(frame: CGRectMake(0, 0, screenWidth, CGFloat((array?.count)!) * 50), style: UITableViewStyle.Plain)
            } else {
                tblList = UITableView(frame: CGRectMake(0, 0, screenWidth, screenHeight - 44), style: UITableViewStyle.Plain)
            }
            tblList?.delegate = self
            tblList?.dataSource = self
            self.inputView = tblList
        }
    }
    
    func setSelectedListValue(selectedValue: String){
        if selectedValue.isEmpty == false{
            self.text = selectedValue
            let selectedValueArray = selectedValue.componentsSeparatedByString(", ")
            for value in selectedValueArray{
                selectedListArray.addObject(value)
                if isMultiSelection == false{
                    self.text = value
                    break
                }
            }
        }
    }
    
    private var doneBlock:((textField:TCTextField) -> ())?
    private var nextBlock:((textField:TCTextField) -> ())?
    private var prevBlock:((textField:TCTextField) -> ())?
    
    func setInputHeaderWith(background:UIColor?,textColor:UIColor?,doneTitle:String? = "Done",prevTitle:String = "Prev",nextTitle:String = "Next",doneBlock:((textField:TCTextField) -> ())?,nextBlock:((textField:TCTextField) -> ())?,prevBlock:((textField:TCTextField) -> ())?) {
        if doneBlock != nil {
            self.doneBlock = doneBlock
        }
        
        if nextBlock != nil {
            self.nextBlock = nextBlock
        }
        
        if prevBlock != nil {
            self.prevBlock = nextBlock
        }
        
        let TCHeader: UIView = UIView(frame: CGRectMake(0, 0, screenWidth, 44))
        TCHeader.backgroundColor = background ?? UIColor.blackColor()
        
        var btnPrev: UIButton?
        var btnNext: UIButton?
        var btnDone: UIButton?
        let btnFont: UIFont? = TCTextField.themeFont ?? UIFont.systemFontOfSize(UIFont.systemFontSize())
        let setBtnBgColor = UIColor.clearColor()
        let setBtnTextColor = textColor ?? UIColor.whiteColor()
        
        if prevBlock != nil{
            btnPrev = UIButton(type: UIButtonType.Custom)
            btnPrev!.setTitle(prevTitle, forState: UIControlState.Normal)
            btnPrev!.setTitleColor(setBtnTextColor, forState: UIControlState.Normal)
            btnPrev!.titleLabel?.font = btnFont!
            btnPrev!.backgroundColor = setBtnBgColor
            let sizeOfText = btnPrev!.currentTitle!.sizeWithAttributes([NSFontAttributeName:btnFont!])
            btnPrev!.frame = CGRectMake(10, 5, sizeOfText.width+5, 34)
            btnPrev!.addTarget(self, action: "prevAction", forControlEvents: UIControlEvents.TouchUpInside)
            TCHeader.addSubview(btnPrev!)
        }
        
        if nextBlock != nil{
            btnNext = UIButton(type: UIButtonType.Custom)
            btnNext!.setTitle(nextTitle, forState: UIControlState.Normal)
            btnNext!.setTitleColor(setBtnTextColor, forState: UIControlState.Normal)
            btnNext!.titleLabel?.font = btnFont!
            btnNext!.backgroundColor = setBtnBgColor
            let sizeOfText = btnNext!.currentTitle!.sizeWithAttributes([NSFontAttributeName:btnFont!])
            btnNext!.frame = CGRectMake(btnPrev!.frame.origin.x + btnPrev!.frame.size.width+10, 5, sizeOfText.width+5, 34)
            btnNext!.addTarget(self, action: "nextAction", forControlEvents: UIControlEvents.TouchUpInside)
            TCHeader.addSubview(btnNext!)
        }
        
        if doneBlock != nil{
            btnDone = UIButton(type: UIButtonType.Custom)
            btnDone!.setTitle(doneTitle, forState: UIControlState.Normal)
            btnDone!.setTitleColor(setBtnTextColor, forState: UIControlState.Normal)
            btnDone!.titleLabel?.font = btnFont!
            btnDone!.backgroundColor = setBtnBgColor
            let sizeOfText = btnDone!.currentTitle!.sizeWithAttributes([NSFontAttributeName:btnFont!])
            btnDone!.frame = CGRectMake(screenWidth - sizeOfText.width - 15, 5, sizeOfText.width+5, 34)
            btnDone!.addTarget(self, action: "doneAction", forControlEvents: UIControlEvents.TouchUpInside)
            TCHeader.addSubview(btnDone!)
        }
        self.inputAccessoryView = TCHeader
    }
    
    func prevAction() {
        if prevBlock != nil {
            prevBlock!(textField: self)
        }
    }
    
    func nextAction() {
        if nextBlock != nil {
            nextBlock!(textField: self)
        }
    }
    
    func doneAction() {
        
        if datePicker != nil {
            let formator = NSDateFormatter()
            if dateFormate != nil {
                formator.dateFormat = self.dateFormate
            } else {
                formator.dateFormat = "dd-MM-yyyy hh:mm:ss";
            }
            self.text = formator.stringFromDate((datePicker?.date)!)
        } else if picker != nil{
            if disPlayKey?.isEmpty == false{
                self.text = pickerArray[(picker?.selectedRowInComponent(0))!] .valueForKey(disPlayKey!) as? String
            }else if pickerColumn == 1 {
                self.text = pickerArray[(picker?.selectedRowInComponent(0))!] as? String
            }else{
                let arrSelected:NSMutableArray = []
                for var i:Int = 0; i < pickerColumn; i++ {
                    //arrSelected.addObject(pickerArray[i][(picker?.selectedRowInComponent(i))!])
                }
                self.text = arrSelected.componentsJoinedByString(", ")
            }
        }else if tblList != nil{
            //            let tmpArray = NSMutableArray()
            //            for indexpath in selectedListArray{
            //                if disPlayKey?.isEmpty == false{
            //                    tmpArray.addObject(listArray[indexpath.row].valueForKey(disPlayKey!)!)
            //                }else{
            //                    tmpArray.addObject(listArray[indexpath.row])
            //                }
            //            }
            self.text = selectedListArray.componentsJoinedByString(", ")
        }
        self .resignFirstResponder()
        
        
        if doneBlock != nil {
            doneBlock!(textField: self)
        }
    }
    
    var leftPadding: CGFloat? {
        didSet{
            if leftPadding > 0{
                self.setPadding(leftPadding!, image: nil, isLeft: true, clickBlock: nil)
            }
        }
    }
    
    var rightPadding: CGFloat? {
        didSet{
            if rightPadding > 0{
                self.setPadding(rightPadding!, image: nil, isLeft: false, clickBlock: nil)
            }
        }
    }
    
    func setPadding(left:CGFloat = 5.0,right:CGFloat = 5.0) {
        self.leftPadding = left
        self.rightPadding = right
    }
    
    private var paddingClickBlock:((textField:TCTextField,isLeft:Bool) -> ())?
    
    func setPadding(var padding:CGFloat = 5.0, image:UIImage? = nil,isLeft:Bool = true,clickBlock:((textField:TCTextField,isLeft:Bool) -> ())?) {
        let btnPadding = UIButton(type: UIButtonType.Custom)
        if padding == 0.0{
            padding = image!.size.width
        }
        btnPadding.frame = CGRectMake(0, 0, padding, self.bounds.size.height)
        if image != nil{
            btnPadding.setImage(image, forState: UIControlState.Normal)
        }
        
        btnPadding.addTarget(self.superview, action: isLeft ? "leftPaddinClickAction" : "rightPaddinClickAction", forControlEvents: UIControlEvents.TouchUpInside)
        if isLeft {
            self.leftView = btnPadding
            self.leftViewMode = .Always
        } else {
            self.rightView = btnPadding
            self.rightViewMode = .Always
        }
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool{
        print(string)
        return true
    }
}

extension TCTextField:UIPickerViewDelegate {
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView{
        let lblPicker = UILabel(frame: CGRectMake(0, 0, pickerView.rowSizeForComponent(component).width, pickerView.rowSizeForComponent(component).height))
        //        lblPicker.backgroundColor = (component == 0 ? UIColor.redColor() : UIColor.orangeColor())
        lblPicker.textColor = self.textColor
        lblPicker.font = self.font
        if disPlayKey?.isEmpty == false {
            lblPicker.text = pickerArray[row].valueForKey(disPlayKey!) as? String
        }else if pickerColumn == 1 {
            lblPicker.text = pickerArray[row] as? String
        }else{
            //lblPicker.text = pickerArray[component][row] as? String
        }
        
        lblPicker.textAlignment = NSTextAlignment.Center
        return lblPicker
    }
}

extension TCTextField:UIPickerViewDataSource {
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int{
        return pickerColumn
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        if pickerColumn == 1{
            return pickerArray.count
        }else{
            return pickerArray[component].count
        }
    }
}

extension TCTextField:UITableViewDelegate {

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell:UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "cell")
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.textLabel?.textAlignment = .Center
        cell.textLabel?.numberOfLines = 0
        if disPlayKey?.isEmpty == false{
            cell.textLabel?.text = listArray[indexPath.row].valueForKey(disPlayKey!) as? String
        }else{
            cell.textLabel?.text = listArray[indexPath.row] as? String
        }
        let selectedView = UIView(frame: CGRectMake(0,0,10,10))
        selectedView.backgroundColor = UIColor.clearColor()
        selectedView.layer.borderColor = self.textColor!.CGColor
        selectedView.layer.borderWidth = 2.0
        cell.accessoryView = selectedView
        
        if selectedListArray .containsObject((cell.textLabel?.text)!){
            selectedView.backgroundColor = self.textColor!
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        var selectValue: String?
        if disPlayKey?.isEmpty == false{
            selectValue = listArray[indexPath.row].valueForKey(disPlayKey!) as? String
        }else{
            selectValue = listArray[indexPath.row] as? String
        }
        
        if isMultiSelection == true{
            if selectedListArray.containsObject(selectValue!){
                selectedListArray.removeObject(selectValue!)
            }else{
                selectedListArray.addObject(selectValue!)
            }
        }else{
            selectedListArray.removeAllObjects()
            selectedListArray.addObject(selectValue!)
        }
        tblList?.reloadData()
    }
}

extension TCTextField:UITableViewDataSource {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return listArray.count
    }

}
