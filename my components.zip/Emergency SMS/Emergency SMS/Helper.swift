//
//  Helper.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/1/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import Foundation
import UIKit

enum UIUserInterfaceIdiom : Int
{
    case Unspecified
    case Phone
    case Pad
}
struct ScreenSize
{
    static let SCREEN_WIDTH         = UIScreen.mainScreen().bounds.size.width
    static let SCREEN_HEIGHT        = UIScreen.mainScreen().bounds.size.height
    static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
}
struct DeviceType
{
    static let IS_IPHONE_4_OR_LESS  = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6          = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6P         = UIDevice.currentDevice().userInterfaceIdiom == .Phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPAD              = UIDevice.currentDevice().userInterfaceIdiom == .Pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    static let IS_IPAD_PRO          = UIDevice.currentDevice().userInterfaceIdiom == .Pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
}

struct FontName
{
    static var HelveticaNeueBold = "HelveticaNeue-Bold"
    static var HelveticaNeueCondensedBlack = "HelveticaNeue-CondensedBlack"
    static var HelveticaNeueMedium = "HelveticaNeue-Medium"
    static var HelveticaNeue = "HelveticaNeue"
    static var HelveticaNeueLight = "HelveticaNeue-Light"
    static var HelveticaNeueCondensedBold = "HelveticaNeue-CondensedBold"
}

struct Color {
    static var themeRed = UIColor(red:1.0, green:0 , blue: 0, alpha: 1)
    static var screenBack = UIColor(red:0.9, green:0.9 , blue:0.9, alpha: 1)
    static var lightDark = UIColor(white:0.8, alpha: 1)
    static var textColor = UIColor(white:0.5, alpha: 1)
    static var cellBack = UIColor(red:0.24, green: 0.25, blue: 0.26, alpha:1)
}

//HelveticaNeue-LightItalic,
//HelveticaNeue-UltraLightItalic,
//HelveticaNeue-UltraLight,
//HelveticaNeue-BoldItalic,
//HelveticaNeue-Italic

func Font(name:String,size:CGFloat) ->UIFont
{
    return UIFont (name:name, size: size * (Screen.width / 320))!
}

class Helper
{
    static let sharedInstance = Helper()
    var request:TCURLRequestSession!
    var dictUser = [String:AnyObject]()
    private init()
    {
        request = TCURLRequestSession()
        
        TCURLRequestSession.showLog = false
        TCURLRequestSession.showloaderBlock = {
            (message:String?) -> () in
            let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let hud = MBProgressHUD.showHUDAddedTo(delegate.window, animated: true)
            hud.labelText = message
        }
        TCURLRequestSession.hideLoaderBlock = {
            () -> () in
            let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
            MBProgressHUD.hideAllHUDsForView(delegate.window, animated: true)
        }
    }
}

