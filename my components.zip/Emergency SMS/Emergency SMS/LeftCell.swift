//
//  LeftCell.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/4/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit


class LeftCell: UITableViewCell {
    
    var imgView:UIImageView!
    var lblName:UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    override init(style: UITableViewCellStyle, reuseIdentifier: String?)
    {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.clipsToBounds = true
        self.backgroundColor = Color.cellBack
        imgView = UIImageView(frame:TCRectMake(x:15, y:10, width:30, height: 30))
        imgView.contentMode = .ScaleAspectFit
        imgView.backgroundColor = UIColor.clearColor()
        imgView.clipsToBounds = true
        self.contentView.addSubview(imgView)
        
        lblName = UILabel(frame:TCRectMake(x: 65,y: 5,width: 200,height: 40))
        lblName.textColor = Color.textColor
        lblName.font = Font(FontName.HelveticaNeueBold, size: 14)
        self.contentView.addSubview(lblName)
        
        let line = UIView(frame:TCRectMake(x: 0,y: 49,width: 320,height: 1))
        line.backgroundColor = Color.lightDark
        line.frame.size.height = 0.5
        self.contentView.addSubview(line)

    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }

}
