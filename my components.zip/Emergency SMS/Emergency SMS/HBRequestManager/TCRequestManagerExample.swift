//
//  TCRequestManagerExample.swift
//  CommonComponent
//
//  Created by  on 31/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation
import UIKit

class TCRequestManagerExample: UIViewController {
    let request = TCURLRequestSession()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.whiteColor()
        
        let scroll = UIScrollView(frame: self.view.bounds)
        scroll.contentSize = CGSizeMake(self.view.frame.size.width, 10000)
        self.view.addSubview(scroll)
        
        let btn = UIButton(type: .Custom)
        btn.frame = CGRectMake(100, 100, 200, 50)
        btn.setTitle("log", forState: .Normal)
        btn.addTarget(self, action: "logbutton", forControlEvents: .TouchUpInside)
        btn.backgroundColor = UIColor.blueColor()
        self.view.addSubview(btn)
        
        for notification in UIApplication.sharedApplication().scheduledLocalNotifications! { // loop through notifications...
            UIApplication.sharedApplication().cancelLocalNotification(notification) // there should be a maximum of one match on UUID
        }
        
        //        NSDateComponents *componentsForFireDate = [calendar components:(NSYearCalendarUnit |   NSHourCalendarUnit | NSMinuteCalendarUnit| NSSecondCalendarUnit | NSWeekdayCalendarUnit) fromDate: now];
        
        
        //        let calender = NSCalendar(identifier: NSCalendarIdentifierGregorian)
        //        let datecomponent = calender?.components([.Second,.Minute,.Hour,.Day,.WeekOfYear,.Month,.Year], fromDate: NSDate())
        //        datecomponent?.second = 0
        //        datecomponent?.minute = 54
        //        datecomponent?.hour = 16
        //        datecomponent?.weekday = 3
        //
        //        let localnoti = UILocalNotification()
        //        //localnoti.fireDate = NSDate(timeInterval: 10, sinceDate: NSDate())
        //        localnoti.fireDate = calender?.dateFromComponents(datecomponent!)
        //        localnoti.repeatInterval = NSCalendarUnit.WeekOfYear
        //        localnoti.alertBody = "Hi hello"
        //        localnoti.userInfo = ["day":"Monday"]
        //        UIApplication.sharedApplication().scheduleLocalNotification(localnoti)
        //        UIApplication.sharedApplication()
        //        print("notification scheduled")
        
        //        request.requestFor("https://staging2.healthywage.com/api/v2/team-profile/120954", type: .GET, parameters: nil).onProgress { (request, total, sent, type) -> () in
        //            print("r1  \(type) -- \(total) : \(sent)")
        //        }.onSuccess { (request, response, error) -> () in
        //            if error == nil {
        //                print("\(response!)")
        //            } else {
        //                print("\(error?.localizedDescription)")
        //            }
        //        }
        
        //        request.requestFor("http://192.168.36.20:8888/index.php", type: .GET, parameters: nil, headers: nil,authorization: .Digest).onProgress { (request, total, sent, type) -> () in
        //            print("r1  \(type) -- \(total) : \(sent)")
        //            }.onSuccess { (request, response, error) -> () in
        //                if error == nil {
        //                    print("\(response!)")
        //                } else {
        //                    print("\(error?.localizedDescription)")
        //                }
        //        }
        
        //        request.requestFor("https://staging2.healthywage.com/api/auth/login", type: .POST, parameters: ["email" : "bradley.demo@healthywage.com","password" : "test"]).onProgress { (request, total, sent, type) -> () in
        //            print("r1  \(type) -- \(total) : \(sent)")
        //            }.onSuccess { (request, response, error) -> () in
        //                if error == nil {
        //                    print("\(response!)")
        //                } else {
        //                    print("\(error?.localizedDescription)")
        //                }
        //        }
        
        // Do any additional setup after loading the view, typically from a nib.
        
        //        let img = UIImage(named: "nature.jpg")
        //        let imgData = UIImageJPEGRepresentation(img!, 0.7)
        //
        //        let dicparams:[String : AnyObject] = ["vEmail":"test3@mailinator.com","vPassword":"12345678","vCountryCode":"91","vPhonenumber":"13174460934","vDeviceToken":"12432323233232fe34f3rf3f3f3ff33335fdjy56","eDevice":"IOS","vAppVersion":"1.3","vFullName":"test 1234","file" : imgData!,"fileName":"image.png","mimeType" : "image/png","fileKey" : "vImage"]
        //
        //        request.requestFor("http://202.131.125.130:8000/AVAIBLE/sign_up.asmx", type: .MULTIPART, parameters: dicparams).onSuccess { (request, response, error) -> () in
        //            if error == nil {
        //                print("\(response!)")
        //            } else {
        //                print("\(error?.localizedDescription)")
        //            }
        //            }.onProgress { (request, total, sent, type) -> () in
        //                print("r1  \(type) -- \(total) : \(sent)")
        //        }
        
        //        NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "pt:", userInfo: req, repeats: false)
        //        NSTimer.scheduledTimerWithTimeInterval(60, target: self, selector: "rt:", userInfo: req, repeats: false)
        //        NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "ct:", userInfo: req, repeats: false)
        //
        //        req.pauseTask()
        
        //
        //
        //
        //
        //        request.requestFor("http://202.131.125.130:8000/AVAIBLE/sign_up.asmx", type: .MULTIPART, parameters: dicparams1).onSuccess { (request, response, error) -> () in
        //            if error == nil {
        //                print("\(response!)")
        //            } else {
        //                print("\(error?.localizedDescription)")
        //            }
        //            }.onProgress { (request, total, sent, type) -> () in
        //                print("r2  \(type) -- \(total) : \(sent)")
        //        }
    }
    
    func logbutton() {
        print("main thread is not blocked")
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        request.storeCredential("admin", password: "mypass")
        TCURLRequestSession.showLog = true
                TCURLRequestSession.showloaderBlock = {
                    (message:String?) -> () in
                    let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
                    let hud = MBProgressHUD.showHUDAddedTo(delegate.window, animated: true)
                    hud.labelText = message
                }
        
                TCURLRequestSession.hideLoaderBlock = {
                    () -> () in
                    let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
                    MBProgressHUD.hideAllHUDsForView(delegate.window, animated: true)
                }
        
        UIApplication.sharedApplication().cancelAllLocalNotifications()
        
        let calender = NSCalendar(identifier: NSCalendarIdentifierGregorian)
        let datecomponents = (calender?.components([.Year,.Month,.WeekOfMonth], fromDate: NSDate()))!
        let dc = NSDateComponents()
        dc.second = 0
        dc.minute = 20
        dc.hour = 19
        dc.year = datecomponents.year
        dc.month = datecomponents.month
        dc.weekOfMonth = datecomponents.weekOfMonth
        dc.weekday = 2
        TC.log(calender?.dateFromComponents(dc))
        
        let localnoti = UILocalNotification()
        //localnoti.fireDate = NSDate(timeInterval: 10, sinceDate: NSDate())
        localnoti.fireDate = calender?.dateFromComponents(dc)
        localnoti.repeatInterval = NSCalendarUnit.WeekOfYear
        localnoti.alertBody = "Hi hello"
        localnoti.userInfo = ["day":"Monday"]
        UIApplication.sharedApplication().scheduleLocalNotification(localnoti)
        UIApplication.sharedApplication()
        print("notification scheduled")
        
        request.requestFor(requestURL: "http://192.168.36.19:8888/index.php", type: .GET,authorization: .Digest,cache: true).onProgress { (request, total, sent, type) -> () in
            print("r1  \(type) -- \(total) : \(sent)")
            }.onSuccess { (request, response, error) -> () in
                //                if error == nil {
                //                    print("\(response!)")
                //                } else {
                //                    print("\(error?.localizedDescription)")
                //                }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pt(task:NSTimer) {
        if let t = task.userInfo as? TCRequestTask {
            t.pauseTask()
        }
    }
    
    func rt(task:NSTimer) {
        if let t = task.userInfo as? TCRequestTask {
            t.resumeTask()
        }
    }
    
    func ct(task:NSTimer) {
        if let t = task.userInfo as? TCRequestTask {
            t.cancelTask()
        }
    }
}