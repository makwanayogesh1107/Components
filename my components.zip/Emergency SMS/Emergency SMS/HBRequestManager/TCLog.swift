//
//  WebserviceViewController.swift
//  CommonComponent
//
//  Created by TC1 on 05/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import UIKit
import Foundation

enum LogType:Int {
    case Consol = 0
    case File
    case View
    case None
}

enum ButtonLocation:Int {
    case TopLeft = 0
    case TopRight
    case Center
    case BottolLeft
    case BottomRight
}

enum ColorType:Int {
    case Light = 0
    case Dark
}

var TC = TCLog.sharedLog

class TCLog: NSObject {
    private var dateFormator:NSDateFormatter!
    var handler:NSFileHandle!
    var viewLog:UIView!
    var txtLog:UITextView!
    var btnLog:UIButton!
    var showType:Bool = false
    var showFormated:Bool = false
    
    var colorType:ColorType? = ColorType.Dark {
        didSet {
            if btnLog != nil {
                btnLog!.layer.borderColor = (colorType == .Dark ? UIColor.blackColor() : UIColor.whiteColor()).CGColor
                btnLog!.setTitleColor((colorType == .Dark ? UIColor.blackColor() : UIColor.whiteColor()), forState: UIControlState.Normal)
            }
        }
    }
    
    var buttonLocation:ButtonLocation? = ButtonLocation.TopLeft {
        didSet {
            self.btnLocation()
        }
    }
    /**
     Log display type
     Consol = log on console
     File = store as log file
     View = it add Log button at upper left cornet by clicking it shows log on running application
     None = No log
     */
    
    var logType:LogType! {
        didSet {
            if btnLog != nil {
                btnLog!.removeFromSuperview()
                btnLog = nil
                if viewLog != nil {
                    viewLog!.removeFromSuperview()
                    viewLog = nil
                }
            }
            
            if logType == LogType.File {
                self.initializeFile()
                
            } else if logType == LogType.View {
                self.initializeFile()
                self.createLogView()
                
                btnLog = UIButton(type: UIButtonType.Custom)
                btnLog!.backgroundColor = UIColor.clearColor()
                btnLog!.layer.borderColor = (colorType == .Dark ? UIColor.blackColor() : UIColor.whiteColor()).CGColor
                btnLog!.layer.borderWidth = 1
                btnLog!.layer.cornerRadius = 5
                btnLog!.frame = CGRectMake(5, 5, 70, 30)
                btnLog!.setTitle("Log", forState: UIControlState.Normal)
                btnLog!.setTitleColor((colorType == .Dark ? UIColor.blackColor() : UIColor.whiteColor()), forState: UIControlState.Normal)
                btnLog!.addTarget(self, action: "showLog", forControlEvents: UIControlEvents.TouchUpInside)
                let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
                delegate.window?.rootViewController?.view.addSubview(btnLog!)
                self.btnLocation()
            }
        }
    }
    private var filePath : String {
        get {
            let path = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.CachesDirectory, NSSearchPathDomainMask.UserDomainMask, true)
            let cachePath = (path as NSArray).objectAtIndex(0) as! NSString
            let logFile = cachePath.stringByAppendingPathComponent("MGLog.log")
            return logFile
        }
    }
    func initializeFile() {
        if !NSFileManager.defaultManager().fileExistsAtPath(filePath) {
            NSFileManager.defaultManager().createFileAtPath(filePath, contents: nil, attributes: nil)
        }
        
        if handler == nil {
            handler = NSFileHandle(forWritingAtPath: filePath)
        }
    }
    
    /**
     Initialize shared object
     */
    
    class var sharedLog:TCLog {
        struct Static {
            static var log: TCLog!
            static var token: dispatch_once_t = 0
        }
        
        dispatch_once(&Static.token) {
            Static.log = TCLog()
            Static.log.logType = LogType.Consol
            Static.log.dateFormator = NSDateFormatter()
            Static.log.dateFormator.dateFormat = "yyyy-MM-dd hh:mm:ss.SSS"
        }
        
        return Static.log
    }
    
    /**
     Create log string
     
     :param: log     object to be logged
     :param: file    file name
     :param: strFunc function name
     :param: intLine line number
     */
    func log(log:AnyObject?...,file:NSString = __FILE__,strFunc:NSString = __FUNCTION__,intLine:Int = __LINE__) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0),  { () -> Void in
            if log.count > 0 {
                let file = ((file.lastPathComponent as NSString).componentsSeparatedByString(".") as NSArray).objectAtIndex(0) as! NSString
                var strparams = ""
                if self.showFormated {
                    strparams = "=========================================\n"
                    strparams += "Time     : \(self.dateFormator.stringFromDate(NSDate()))\nFile     : \(file)\nFunction : \(strFunc)\nLine No  : \(intLine)\n"
                    strparams += "=========================================\n"
                    for index in 0..<log.count {
                        if self.showType {
                            strparams += "Type     : \(object_getClass(log[index]!))\nData     : "
                        }
                        if let param = log[index] {
                            strparams += "\(param)\n"
                        } else {
                            strparams += "\(NSNull())\n"
                        }
                        strparams += "-----------------------------------------\n"
                        
                    }
                } else {
                    strparams += "\(self.dateFormator.stringFromDate(NSDate())) : [\(file) : \(strFunc)] \(intLine) : "
                    for index in 0..<log.count {
                        if self.showType {
                            strparams += "\(object_getClass(log[index]!)) : "
                        }
                        if let param = log[index] {
                            strparams += "\(param)\n"
                        } else {
                            strparams += "\(NSNull())\n"
                        }
                    }
                }
                switch self.logType! {
                case .Consol :
                    self.consolLog(strparams)
                case .File :
                    self.fileLog(strparams)
                case .View :
                    self.fileLog(strparams)
                    self.viewLog(strparams)
                case .None :
                    ""
                }
            }
        })
    }
    
    
    deinit {
        handler.closeFile()
    }
    
    /**
     Print log on consol
     
     :param: strPrintLine log string
     */
    
    func consolLog(strPrintLine:NSString) {
        print(strPrintLine)
    }
    
    /**
     Print log on File
     
     :param: strPrintLine log string
     */
    
    func fileLog(strPrintLine:NSString) {
        handler.seekToEndOfFile()
        handler.writeData(strPrintLine.dataUsingEncoding(NSUTF8StringEncoding)!)
        
    }
    
    /**
     Print log Screen
     
     :param: strPrintLine log string
     */
    
    func viewLog(strPrintLine:NSString) {
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            if let _ = self.viewLog.superview {
                self.txtLog!.text = NSString(format: "%@%@",strPrintLine,self.txtLog!.text) as String
            }
        }
    }
    
    func createLogView() {
        viewLog = UIView(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.size.width, UIScreen.mainScreen().bounds.size.height))
        viewLog!.backgroundColor = UIColor.whiteColor()
        
        txtLog = UITextView(frame: CGRectMake(5, 40, viewLog!.frame.size.width - 10, viewLog!.frame.size.height - 45))
        txtLog!.backgroundColor = UIColor.clearColor()
        txtLog!.editable = false
        txtLog!.textColor = UIColor.blackColor()
        txtLog!.layer.cornerRadius = 5
        txtLog!.layer.borderColor = UIColor.blackColor().CGColor
        txtLog!.layer.borderWidth = 1
        viewLog!.addSubview(txtLog!)
        
        let btnClose = UIButton(type:UIButtonType.Custom)
        btnClose.backgroundColor = UIColor.clearColor()
        btnClose.layer.borderColor = UIColor.blackColor().CGColor
        btnClose.layer.borderWidth = 1
        btnClose.layer.cornerRadius = 5
        btnClose.frame = CGRectMake(5, 5, 70, 30)
        btnClose.setTitle("Close", forState: UIControlState.Normal)
        btnClose.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        btnClose.addTarget(self, action: "hideLog", forControlEvents: UIControlEvents.TouchUpInside)
        viewLog!.addSubview(btnClose)
        
        let btnClear = UIButton(type:UIButtonType.Custom)
        btnClear.backgroundColor = UIColor.clearColor()
        btnClear.layer.borderColor = UIColor.blackColor().CGColor
        btnClear.layer.borderWidth = 1
        btnClear.layer.cornerRadius = 5
        btnClear.frame = CGRectMake(viewLog!.frame.size.width - 75, 5,70, 30)
        btnClear.setTitle("Clear", forState: UIControlState.Normal)
        btnClear.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        btnClear.addTarget(self, action: "clearLog", forControlEvents: UIControlEvents.TouchUpInside)
        viewLog!.addSubview(btnClear)
    }
    
    /**
     Show log screen
     */
    
    private func showLog() {
        let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
        delegate.window?.rootViewController?.view.addSubview(viewLog!)
        do {
            txtLog.text = try String(contentsOfFile: filePath)
        } catch {
            
        }
        btnLog!.hidden = true
        TC.log("moinuddin girach")
    }
    
    /**
     Hide log screen
     */
    
    private func hideLog() {
        viewLog!.removeFromSuperview()
        if logType == LogType.View {
            btnLog!.hidden = false
        }
    }
    
    /**
     clear log
     */
    
    func clearLog() {
        if txtLog != nil {
            txtLog!.text = ""
        }
        handler.truncateFileAtOffset(0)
    }
    
    func btnLocation() {
        if btnLog != nil {
            switch buttonLocation! {
            case .TopLeft:
                btnLog?.frame = CGRectMake(5, 5, 70, 30)
            case .TopRight:
                btnLog?.frame = CGRectMake(UIScreen.mainScreen().bounds.size.width - 75, 5, 70, 30)
            case .Center:
                btnLog?.frame = CGRectMake((UIScreen.mainScreen().bounds.size.width - 70) / 2, (UIScreen.mainScreen().bounds.size.height - 30) / 2, 70, 30)
            case .BottolLeft:
                btnLog?.frame = CGRectMake(5, UIScreen.mainScreen().bounds.size.height - 35, 70, 30)
            case .BottomRight:
                btnLog?.frame = CGRectMake(UIScreen.mainScreen().bounds.size.width - 75, UIScreen.mainScreen().bounds.size.height - 35, 70, 30)
            }
        }
    }
    
}