//
//  TCRequestTask.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

class TCRequestTask : NSObject {
    var authentication:Authentication = .Basic
    var headers: Dictionary<String,String>?
    var httpHeaders : NSHTTPURLResponse?
    var progressStatus = ProgressType.Upload
    var success:((request:TCRequestTask,response:AnyObject?,error:NSError?)->())?
    var progress:((request:TCRequestTask,total:Int64,sent:Int64,type:ProgressType)->())?
    var task : NSURLSessionTask?
    var cache : Bool = false
    
    /**
     Set success block
     
     - parameter success: success block
     
     - returns: task
     */
    
    func onSuccess(success:((request:TCRequestTask,response:AnyObject?,error:NSError?)->())?) -> TCRequestTask {
        if success != nil {
            self.success = success
        }
        return self
    }
    
    /**
     Set progress block
     
     - parameter success: progress block
     
     - returns: task
     */
    
    func onProgress(progress:((request:TCRequestTask,total:Int64,sent:Int64,type:ProgressType)->())?) -> TCRequestTask {
        if progress != nil {
            self.progress = progress
        }
        return self
    }
    
    /**
     paus task
     */
    
    func pauseTask() {
        if self.task != nil {
            if task?.state == NSURLSessionTaskState.Running {
                task?.suspend()
            }
        }
    }
    
    /**
     resume task
     */
    
    func resumeTask() {
        if self.task != nil {
            if task?.state == NSURLSessionTaskState.Suspended {
                task?.resume()
            }
        }
    }
    
    /**
     cancel task
     */
    
    func cancelTask() {
        if self.task != nil {
            if task?.state != NSURLSessionTaskState.Completed {
                task?.cancel()
            }
        }
    }
}