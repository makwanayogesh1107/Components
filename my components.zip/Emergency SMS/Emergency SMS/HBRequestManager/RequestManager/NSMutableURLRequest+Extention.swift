//
//  NSMutableURLRequest+Extention.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

extension NSMutableURLRequest {
    convenience init(url:String,type:RequestType,parameters:NSDictionary? = nil,headers:NSDictionary? = nil,authorization:Authentication = .NoAuth,timeOut:NSTimeInterval = 30) {
        self.init(URL: NSURL(string: url)!, cachePolicy: .UseProtocolCachePolicy, timeoutInterval: timeOut)
        var strUrl = ""
        switch type {
        case .GET:
            if let parms = parameters {
                strUrl = url + "?" + (parms.createParams() as! String)
            } else {
                strUrl = url
            }
        default:
            strUrl = url
        }
        
        let generalDelimitersToEncode = "#[]@"
        let subDelimitersToEncode = "!$&'()*+,;="
        
        let allowedCharacterSet = NSCharacterSet.URLQueryAllowedCharacterSet().mutableCopy() as! NSMutableCharacterSet
        allowedCharacterSet.removeCharactersInString(generalDelimitersToEncode + subDelimitersToEncode)
        
        let requestURL = NSURL(string: strUrl.stringByAddingPercentEncodingWithAllowedCharacters(allowedCharacterSet)!)
        
        self.URL = requestURL
        self.HTTPMethod = type.requestType()
        
        switch type {
        case .GET,.DELETE:
            self.HTTPBody = nil
        case .POST,.PUT :
            self.HTTPBody = (parameters == nil) ? nil : parameters!.createBody()
        case .MULTIPART :
            let boundry = "Boundry-\(NSUUID().UUIDString)"
            let bodyData = parameters!.createMUltipartBody(withBoundry: boundry)
            self.HTTPBody = bodyData
            self.addValue("multipart/form-data; boundary=\(boundry)", forHTTPHeaderField: "Content-Type")
        }
        
        if headers != nil && headers?.count > 0{
            for (key,value) in headers! {
                self.addValue(value as! String, forHTTPHeaderField: key as! String)
            }
        }
        
        if authorization == .Digest {
            self.addValue(TCURLRequestSession.credentials!.createDigestData(), forHTTPHeaderField: "Authorization")
        }
    }
}
