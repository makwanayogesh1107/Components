//
//  HTTPStatusCode.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

enum HTTPStatusCode: Int {
    case Continue = 100
    case SwitchingProtocols = 101
    
    case OK = 200
    case Created = 201
    case Accepted = 202
    case NonAuthoritativeInformation = 203
    case NoContent = 204
    case ResetContent = 205
    case PartialContent = 206
    
    case MultipleChoices = 300
    case MovedPermanently = 301
    case Found = 302
    case SeeOther = 303
    case NotModified = 304
    case UseProxy = 305
    case Unused = 306
    case TemporaryRedirect = 307
    
    case BadRequest = 400
    case Unauthorized = 401
    case PaymentRequired = 402
    case Forbidden = 403
    case NotFound = 404
    case MethodNotAllowed = 405
    case NotAcceptable = 406
    case ProxyAuthenticationRequired = 407
    case RequestTimeout = 408
    case Conflict = 409
    case Gone = 410
    case LengthRequired = 411
    case PreconditionFailed = 412
    case RequestEntityTooLarge = 413
    case RequestUriTooLong = 414
    case UnsupportedMediaType = 415
    case RequestedRangeNotSatisfiable = 416
    case ExpectationFailed = 417
    
    case InternalServerError = 500
    case NotImplemented = 501
    case BadGateway = 502
    case ServiceUnavailable = 503
    case GatewayTimeout = 504
    case HttpVersionNotSupported = 505
    
    case InvalidUrl = -1001
    
    case UnknownStatus = 0
    
    init(statusCode: Int) {
        self = HTTPStatusCode(rawValue: statusCode) ?? .UnknownStatus
    }
    
    var statusDescription: String {
        get {
            switch self {
            case .Continue:
                return "Continue"
            case .SwitchingProtocols:
                return "Switching protocols"
            case .OK:
                return "OK"
            case .Created:
                return "Created"
            case .Accepted:
                return "Accepted"
            case .NonAuthoritativeInformation:
                return "Non authoritative information"
            case .NoContent:
                return "No content"
            case .ResetContent:
                return "Reset content"
            case .PartialContent:
                return "Partial Content"
            case .MultipleChoices:
                return "Multiple choices"
            case .MovedPermanently:
                return "Moved Permanently"
            case .Found:
                return "Found"
            case .SeeOther:
                return "See other Uri"
            case .NotModified:
                return "Not modified"
            case .UseProxy:
                return "Use proxy"
            case .Unused:
                return "Unused"
            case .TemporaryRedirect:
                return "Temporary redirect"
            case .BadRequest:
                return "Bad request"
            case .Unauthorized:
                return "Access denied"
            case .PaymentRequired:
                return "Payment required"
            case .Forbidden:
                return "Forbidden"
            case .NotFound:
                return "Page not found"
            case .MethodNotAllowed:
                return "Method not allowed"
            case .NotAcceptable:
                return "Not acceptable"
            case .ProxyAuthenticationRequired:
                return "Proxy authentication required"
            case .RequestTimeout:
                return "Request timeout"
            case .Conflict:
                return "Conflict request"
            case .Gone:
                return "Page is gone"
            case .LengthRequired:
                return "Lack content length"
            case .PreconditionFailed:
                return "Precondition failed"
            case .RequestEntityTooLarge:
                return "Request entity is too large"
            case .RequestUriTooLong:
                return "Request uri is too long"
            case .UnsupportedMediaType:
                return "Unsupported media type"
            case .RequestedRangeNotSatisfiable:
                return "Request range is not satisfiable"
            case .ExpectationFailed:
                return "Expected request is failed"
            case .InternalServerError:
                return "Internal server error"
            case .NotImplemented:
                return "Server does not implement a feature for request"
            case .BadGateway:
                return "Bad gateway"
            case .ServiceUnavailable:
                return "Service unavailable"
            case .GatewayTimeout:
                return "Gateway timeout"
            case .HttpVersionNotSupported:
                return "Http version not supported"
            case .InvalidUrl:
                return "Invalid url"
            default:
                return "Unknown status code"
            }
        }
    }
}
