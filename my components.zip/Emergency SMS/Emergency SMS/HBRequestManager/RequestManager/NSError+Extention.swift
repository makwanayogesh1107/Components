//
//  NSError+Extention.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

extension NSError {
    convenience init(code:Int) {
        let text = HTTPStatusCode(statusCode: code).statusDescription
        self.init(domain: "HTTP", code: code, userInfo: [NSLocalizedDescriptionKey: text])
    }
}