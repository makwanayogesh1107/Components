//
//  NSDictionary+Extention.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

extension NSDictionary {
    /**
     Check either body parameters contains any object other then string in parameters
     
     - returns: true if parameters containt any object other then string
     */
    private func checkForBodyTypeFromParams() -> Bool {
        if self.count > 0 {
            for (_, value) in self {
                if value.isKindOfClass(NSArray.self) || value.isKindOfClass(NSDictionary.self) || value.isKindOfClass(NSSet.self) {
                    return true
                }
            }
        }
        return false
    }
    /**
     create body based on the dictionary data
     
     - returns: return body data
     */
    func createBody() -> NSData? {
        if self.count > 0 {
            if self.checkForBodyTypeFromParams() {
                do {
                    let jsonData = try NSJSONSerialization.dataWithJSONObject(self, options: .PrettyPrinted) as NSData
                    return jsonData
                } catch let error {
                    print(error)
                }
            } else {
                return self.createParams()?.dataUsingEncoding(NSUTF8StringEncoding)
            }
        }
        return nil
    }
    /**
     create parameter string
     
     - returns: parameter string
     */
    func createParams() -> NSString? {
        if self.count > 0 {
            var arrParams = [String]()
            for (key, value) in self {
                arrParams.append(("\(key)=\(value)"))
            }
            if arrParams.count > 0 {
                return (arrParams as NSArray).componentsJoinedByString("&")
            }
        }
        return nil
    }
    
    /**
     create mutypart body data
     
     - parameter boundry: multipartbody boundry
     
     - returns: body data
     */
    
    /*func createMUltipartBody(withBoundry boundry:String) -> NSData? {
        
        let bodyData = NSMutableData()
        if self.count > 0 {
            for (key, value) in self {
                if ((key as! String == "file") || (key as! String == "fileName") || (key as! String == "mimeType") || (key as! String == "fileKey")) != true {
                    bodyData.appendData("--\(boundry)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                    bodyData.appendData("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                    bodyData.appendData("\(value)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                }
            }
            
            if self["file"] != nil && ((self["file"] as! NSData).length > 0) && self["fileName"] != nil && self["mimeType"] != nil && self["fileKey"] != nil {
                bodyData.appendData("--\(boundry)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                bodyData.appendData("Content-Disposition: form-data; name=\"\(self["fileKey"]!)\"; filename=\"\(self["fileName"]!)\"\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                bodyData.appendData("Content-Type: \(self["mimeType"]!)\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                bodyData.appendData(self["file"] as! NSData)
                bodyData.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                bodyData.appendData("--\(boundry)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
            }
        }
        return bodyData
    }*/
    
    func createMUltipartBody(withBoundry boundry:String) -> NSData? {
        
        let bodyData = NSMutableData()
        if self.count > 0 {
            for (key, value) in self {
                if (key as! String == "imgData") != true {
                    bodyData.appendData("--\(boundry)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                    bodyData.appendData("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                    bodyData.appendData("\(value)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                }
            }
            
            if let images = self["imgData"] as? NSArray {
                for image in images {
                    if let file = image["file"] as? NSData where file.length > 0,let mime = image["mimeType"] as? String, let fileKey = image["fileKey"] as? String,let name = image["fileName"] as? String {
                        
                        bodyData.appendData("--\(boundry)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        print("Content-Disposition: form-data; name=\"\(fileKey)\"; filename=\"\(name)\"\r\n")
                        bodyData.appendData("Content-Disposition: form-data; name=\"\(fileKey)\"; filename=\"\(name)\"\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        print("Content-Type: \(mime)\r\n\r\n")
                        bodyData.appendData("Content-Type: \(mime)\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                        bodyData.appendData(file)
                        bodyData.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
                    }
                }
            }
            bodyData.appendData("--\(boundry)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
            
        }
        return bodyData
    }
    
}
