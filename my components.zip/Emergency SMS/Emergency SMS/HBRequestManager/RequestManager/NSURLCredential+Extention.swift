//
//  NSURLCredential+Extention.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation

extension NSURLCredential {
    
    /**
     create digest authenticatin header data
     
     - returns: digest string
     */
    
    func createDigestData() -> String {
        let username = self.user
        let password = self.password
        let realarm = "Restricted area"
        let nonce =  String.randomStringWithLength(10)
        let nc = String.randomStringWithLength(10)
        let cnonce = String.randomStringWithLength(10)
        let opaque = String.randomStringWithLength(10)
        let qop = "auth"
        let A1 = "\(username!):\(realarm):\(password!)"
        let A2 = "GET:/index.php"
        let uri = "/index.php"
        let response = "\(A1.md5()):\(nonce):\(nc):\(cnonce):\(qop):\(A2.md5())".md5()
        
        let digestString = "Digest nonce=\"\(nonce)\", uri=\"\(uri)\", qop=\"\(qop)\", nc=\"\(nc)\", cnonce=\"\(cnonce)\", response=\"\(response)\", opaque=\"\(opaque)\", realm=\"\(realarm)\", username=\"\(username!)\""
        print(digestString)
        
        return digestString
    }
}