//
//  TCURLRequestSession.swift
//  RequestController
//
//  Created by  on 23/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import Foundation
import UIKit

enum RequestType:String {
    case GET
    case POST
    case PUT
    case DELETE
    case MULTIPART
    
    func requestType() -> String {
        switch self {
        case .GET:
            return "GET"
        case .POST:
            return "POST"
        case .PUT:
            return "PUT"
        case .DELETE:
            return "DELETE"
        case .MULTIPART:
            return "POST"
        }
    }
}

enum ResponseType:Int {
    case StringType = 0
    case JSONObject
    case DataType
    case Image
}

enum Authentication:Int {
    case NoAuth = 0
    case Basic
    case Digest
    case OAuth
}

enum ProgressType:Int {
    case Upload = 0
    case Download
}

class TCURLRequestSession :NSObject,NSURLSessionDataDelegate,UIAlertViewDelegate  {
    static var timeout = 60.0
    static var session : NSURLSession?
    static var configuration : NSURLSessionConfiguration?
    private var tasks = Dictionary<Int,TCRequestTask>()
    static var credentials:NSURLCredential?
    static var showloaderBlock:((message:String?)->())?
    static var hideLoaderBlock:(()->())?
    static var showLog:Bool = false
    static var invalidTokenBlock:(() -> ())?
    static var invalidTokenCode:Int?
    /**
     Set Session default configuration
     */
    class func setDefaultConfiguration() {
        if configuration == nil {
            configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
            configuration!.timeoutIntervalForRequest = timeout
            configuration!.timeoutIntervalForResource = timeout
            configuration!.requestCachePolicy = .UseProtocolCachePolicy
            configuration!.networkServiceType = .NetworkServiceTypeBackground
            configuration!.discretionary = true
            configuration!.HTTPAdditionalHeaders = ["Accept":"application/json","os" : "iOS","device" : self.getDeviceModel(),"app_version" : self.versionBuild(),"os_version" : UIDevice.currentDevice().systemVersion]
            configuration?.HTTPMaximumConnectionsPerHost = 2
        }
    }
    private class func versionBuild() -> String {
        let dictionary = NSBundle.mainBundle().infoDictionary!
        let version = dictionary["CFBundleShortVersionString"] as! String
        let build = dictionary["CFBundleVersion"] as! String
        return "\(version)(\(build))"
    }
    private class func getDeviceModel() -> String {
        
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8 where value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro"
        case "AppleTV5,3":                              return "Apple TV"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
    
    override init() {
        super.init()
        
        TCURLRequestSession.setDefaultConfiguration()
        TCURLRequestSession.session = NSURLSession(configuration: TCURLRequestSession.configuration!,delegate: self,delegateQueue:nil)
        
        //NSURLCache.sharedURLCache().removeAllCachedResponses()
        let cach = NSURLCache(memoryCapacity: 4 * 1024 * 1024, diskCapacity: 100 * 1024 * 1024, diskPath: nil)
        NSURLCache.setSharedURLCache(cach)
        
    }
    /**
     Initialize request
     
     - parameter url:           Request url
     - parameter type:          Request method
     - parameter parameters:    Request parameters
     - parameter headers:       Request header if any
     - parameter authorization: Request authorization if required
     - parameter cache:         Catch requests
     
     - returns: Request task object
     */
     //    func requestFor(RequestURL url:String,type:RequestType,parameters:[String : AnyObject]?,headers:[String : AnyObject]? = nil,authorization:Authentication = .NoAuth,cache:Bool = false) -> TCRequestTask {
     //        return self.requestFor(RequestURL: url, type: type, parameters: parameters, headers: headers, authorization: authorization, cache: cache, showLoader: false)
     //    }
    
    func requestFor(requestURL url:String,type:RequestType,parameters:[String : AnyObject]? = nil,headers:[String : AnyObject]? = nil,authorization:Authentication = .NoAuth,cache:Bool = false,loadinMessage:String? = "Loading...") -> TCRequestTask {
        
        if authorization == .Digest && TCURLRequestSession.credentials == nil {
            self.askCredentials()
            return TCRequestTask()
        }
        
        let request = NSMutableURLRequest(url: url, type: type, parameters: parameters, headers: headers, authorization: authorization,timeOut:TCURLRequestSession.timeout)
        
        if TCURLRequestSession.showloaderBlock != nil {
            TCURLRequestSession.showloaderBlock!(message: loadinMessage)
        }
        let downloadTask = TCURLRequestSession.session?.downloadTaskWithRequest(request)
        if tasks[(downloadTask?.taskIdentifier)!] == nil {
            let reqTask = TCRequestTask()
            reqTask.cache = cache
            reqTask.task = downloadTask
            if self.getCatchedResponse(reqTask) {
                downloadTask?.cancel()
                return reqTask
            } else {
                reqTask.authentication = authorization
                tasks[(downloadTask?.taskIdentifier)!] = reqTask
                downloadTask?.resume()
                return tasks[(downloadTask?.taskIdentifier)!]!
            }
        }
        
        return tasks[(downloadTask?.taskIdentifier)!]!
    }
    
    // URLSession Delegates
    
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        if let response = self.getResponseForTask(task), progress = response.progress {
            progress(request: response,total: task.countOfBytesExpectedToSend,sent: task.countOfBytesSent,type: .Upload)
        }
    }
    
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didFinishDownloadingToURL location: NSURL) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
        if let response = self.getResponseForTask(downloadTask) {
            response.httpHeaders = downloadTask.response as? NSHTTPURLResponse
            if let code = response.httpHeaders?.statusCode where response.httpHeaders?.statusCode > 299 {
                if let success = response.success {
                    success(request: response,response: nil,error: NSError(code: code))
                }
            } else {
                if let data = NSData(contentsOfURL: location) {
                    if data.length > 0 {
                        if response.cache {
                            self.cacheResponsefor(data, forTask: downloadTask)
                        }
                        do {
                            let jsonData = try NSJSONSerialization.JSONObjectWithData(data, options: .MutableContainers)
                           /* print(jsonData)
                            if let success = jsonData["settings"]!!["success"] as? NSNumber {
                                if success.integerValue == TCURLRequestSession.invalidTokenCode && TCURLRequestSession.invalidTokenCode != nil {
                                    dispatch_after(time, dispatch_get_main_queue(), {
                                        if let invalidBlock = TCURLRequestSession.invalidTokenBlock {
                                            invalidBlock()
                                        }
                                    })
                                    return
                                }
                            }*/
                            if TCURLRequestSession.showLog {
                                TC.log("Header\n", response.httpHeaders?.allHeaderFields)
                                TC.log("Data\n", jsonData)
                            }
                            dispatch_after(time, dispatch_get_main_queue(), {
                                if let success = response.success {
                                    success(request: response,response:jsonData,error:nil)
                                }
                                self.hideLoader()
                            })
                            
                        } catch let error as NSError {
                            if TCURLRequestSession.showLog {
                                TC.log("Header\n", response.httpHeaders?.allHeaderFields)
                                TC.log("Error\n", error)
                            }
                            dispatch_after(time, dispatch_get_main_queue(), {
                                if let success = response.success {
                                    success(request: response,response:nil,error:error)
                                }
                                self.hideLoader()
                            })
                        }
                    } else {
                        let error = NSError(code: (response.httpHeaders?.statusCode)!)
                        if TCURLRequestSession.showLog {
                            TC.log("Header\n", response.httpHeaders?.allHeaderFields)
                            TC.log("Error\n", error)
                        }
                        dispatch_after(time, dispatch_get_main_queue(), {
                            if let success = response.success {
                                success(request: response,response: nil,error:error)
                            }
                            self.hideLoader()
                        })
                    }
                } else {
                    let error = NSError(code: (response.httpHeaders?.statusCode)!)
                    if TCURLRequestSession.showLog {
                        TC.log("Header\n", response.httpHeaders?.allHeaderFields)
                        TC.log("Error\n", error)
                    }
                    dispatch_after(time, dispatch_get_main_queue(), {
                        if let success = response.success {
                            success(request: response,response: nil,error:error)
                        }
                        self.hideLoader()
                    })
                }
            }
            self.removeTask(downloadTask)
        }
        dispatch_after(time, dispatch_get_main_queue(), {
            
        })
    }
    
    private func hideLoader() {
        if TCURLRequestSession.hideLoaderBlock != nil {
            TCURLRequestSession.hideLoaderBlock!()
        }
    }
    
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        if let response = self.getResponseForTask(downloadTask) {
            if let progress = response.progress {
                progress(request: response,total: downloadTask.countOfBytesExpectedToReceive,sent: downloadTask.countOfBytesReceived,type: .Download)
            }
        }
    }
    
    func URLSession(session: NSURLSession, downloadTask: NSURLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {
    }
    
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didReceiveChallenge challenge: NSURLAuthenticationChallenge, completionHandler: (NSURLSessionAuthChallengeDisposition, NSURLCredential?) -> Void) {
        if let req = getResponseForTask(task) {
            switch req.authentication {
            case .NoAuth,.Digest:
                completionHandler(.RejectProtectionSpace,nil)
            case .Basic:
                completionHandler(.UseCredential,TCURLRequestSession.credentials)
            default:
                ""
            }
        }
    }
    
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didCompleteWithError error: NSError?) {
        if let response = self.getResponseForTask(task) {
            response.httpHeaders = task.response as? NSHTTPURLResponse
            let delay = 0.1 * Double(NSEC_PER_SEC)
            let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
            dispatch_after(time, dispatch_get_main_queue(), {
                response.success!(request: response,response: nil,error:error)
                self.hideLoader()
            })
            
            
            if TCURLRequestSession.showLog {
                TC.log("Header\n", response.httpHeaders?.allHeaderFields)
                TC.log("Error\n", error)
            }
        } else {
            
        }
    }
    
    /**
     Gives request object from download task
     
     - parameter task: download task
     
     - returns: requestobject
     */
    
    func getResponseForTask(task:NSURLSessionTask) -> TCRequestTask? {
        return tasks[task.taskIdentifier]
    }
    
    /**
     Remove completed tasks
     
     - parameter task: download task
     */
    
    func removeTask(task:NSURLSessionTask) {
        tasks.removeValueForKey(task.taskIdentifier)
    }
    
    /**
     Store credentials
     
     - parameter userId:   user id
     - parameter password: password
     */
    
    func storeCredential(userId:String,password:String) {
        TCURLRequestSession.credentials = NSURLCredential(user: userId, password: password, persistence: NSURLCredentialPersistence.None)
    }
    /**
     Prompt aler if credential is not stored and requiest is created with authentication
     */
    func askCredentials() {
        let alert1 = UIAlertController(title: "Credential Missing", message: "This request required credential please enter", preferredStyle: .Alert)
        
        alert1.addTextFieldWithConfigurationHandler({ (text:UITextField) -> Void in
            
        })
        
        alert1.addTextFieldWithConfigurationHandler({ (text:UITextField) -> Void in
            text.secureTextEntry = true
            
        })
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction) -> Void in
            TCURLRequestSession.credentials = NSURLCredential(user: alert1.textFields![0].text!, password: alert1.textFields![1].text!, persistence: .ForSession)
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        alert1.addAction(okAction)
        alert1.addAction(cancelAction)
        
        (UIApplication.sharedApplication().delegate as! AppDelegate).window?.rootViewController?.presentViewController(alert1, animated: true, completion: nil)
    }
    
    /**
     store response to cache
     
     - parameter data: data whic is to be cached
     - parameter task: data task for which data will be cached
     */
    
    func cacheResponsefor(data:NSData,forTask task:NSURLSessionTask) {
        let allHeaders = (task.response as? NSHTTPURLResponse)?.allHeaderFields
        let formatter = NSDateFormatter()
        formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
        let strDate = allHeaders!["Expires"]
        let date = formatter.dateFromString(strDate as! String)
        if NSDate().compare(date!) == NSComparisonResult.OrderedAscending {
            let cachedRes = NSCachedURLResponse(response: task.response!, data: data)
            NSURLCache.sharedURLCache().storeCachedResponse(cachedRes, forRequest: task.originalRequest!)
        }
    }
    
    /**
     it will check if response is cached
     
     - parameter requestTask: request task
     
     - returns: return true if response is cached
     */
    
    func getCatchedResponse(requestTask:TCRequestTask) -> Bool {
        
        if let catchRes = NSURLCache.sharedURLCache().cachedResponseForRequest((requestTask.task?.currentRequest)!) {
            let allHeaders = (catchRes.response as? NSHTTPURLResponse)?.allHeaderFields
            let formatter = NSDateFormatter()
            formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
            let strDate = allHeaders!["Expires"]
            let date = formatter.dateFromString(strDate as! String)
            if NSDate().compare(date!) == NSComparisonResult.OrderedAscending {
                if catchRes.data.length > 0 {
                    
                    let delay = 0.1 * Double(NSEC_PER_SEC)
                    let time = dispatch_time(DISPATCH_TIME_NOW, Int64(delay))
                    
                    do {
                        let jsonData = try NSJSONSerialization.JSONObjectWithData(catchRes.data, options: .MutableContainers)
                        if TCURLRequestSession.showLog {
                            TC.log("Header\n", allHeaders)
                            TC.log("Data\n", jsonData)
                        }
                        
                        dispatch_after(time, dispatch_get_main_queue(), {
                            requestTask.success!(request: requestTask,response:jsonData,error:nil)
                            self.hideLoader()
                        })
                    } catch {
                        return false
                    }
                    return true
                }
            }
        }
        return false
    }
}
