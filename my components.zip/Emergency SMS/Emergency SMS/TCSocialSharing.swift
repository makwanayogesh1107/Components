//
//  WebserviceViewController.swift
//  CommonComponent
//
//  Created by  on 05/12/15.
//  Copyright © 2015 TC. All rights reserved.
//

import UIKit
import Social

class TCSocialSharing:NSObject
{
    private var arrMedia:NSMutableArray!
    override init()
    {
        super.init()
        arrMedia=NSMutableArray()
    }
    private func shareText(strText:String)
    {
        arrMedia.addObject(strText)   
    }
    private func shareImages(arrImages:[UIImage])
    {
        for imgData in arrImages
        {
            let imgData=UIImagePNGRepresentation(imgData)
            arrMedia.addObject(imgData!)
        }
    }
    private func shareVideo(arrVideoURL:[NSURL])
    {
        arrMedia.addObjectsFromArray(arrVideoURL)
    }
    private func shareLink(urlLink:NSURL)
    {
        arrMedia.addObject(urlLink)
    }
    func share(text:String?,urlLink:String?=nil,arrImages:[UIImage]=[],arrVideoURL:[NSURL]=[])
    {
        if text != nil && text != ""
        {
            self.shareText(text!)
        }
        if arrImages.count != 0
        {
            self.shareImages(arrImages)
        }
        if arrVideoURL.count != 0
        {
            self.shareVideo(arrVideoURL)
        }
        if urlLink != nil
        {
            self.shareLink(NSURL(string:urlLink!)!)
        }
        
        let activityViewController = UIActivityViewController(activityItems:arrMedia as [AnyObject],applicationActivities:nil)
        let appDel=UIApplication.sharedApplication().delegate as! AppDelegate
        appDel.window!.rootViewController!.presentViewController(activityViewController, animated: true, completion: nil)
        
    }
    func shareOnFacebook(text:String?="Enter Text",link:String?=nil,images:[UIImage])
    {
        let viewController = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
        
        if text != nil
        {
            viewController.setInitialText(text)
        }
        
        if link != nil
        {
            viewController.addURL(NSURL(string:link!))
        }
        
        for image in images
        {
            viewController.addImage(image)
        }

        let appDel=UIApplication.sharedApplication().delegate as! AppDelegate
        appDel.window!.rootViewController!.presentViewController(viewController, animated: true, completion: nil)
    }
    func shareOnTwitter(text:String?="Enter Text",link:String?=nil,images:[UIImage])
    {
        let viewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        
        if text != nil
        {
            viewController.setInitialText(text)
        }
        
        if link != nil
        {
            viewController.addURL(NSURL(string:link!))
        }
        
        for image in images
        {
            viewController.addImage(image)
        }
        
        let appDel=UIApplication.sharedApplication().delegate as! AppDelegate
        appDel.window!.rootViewController!.presentViewController(viewController, animated: true, completion: nil)
    }

}
