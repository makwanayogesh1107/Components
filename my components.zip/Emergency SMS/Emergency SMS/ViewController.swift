//
//  ViewController.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 4/28/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
