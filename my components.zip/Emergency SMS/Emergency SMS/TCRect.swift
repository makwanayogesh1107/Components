
import Foundation
import UIKit

enum DefaultType {
    case ip5
    case ip6
    case ip6p
}

var defaultType:DefaultType = .ip5

func TCRectMake(x x:AnyObject,y:AnyObject,width:AnyObject,height:AnyObject) -> CGRect {
    return CGRect(x: CGFloat(x as! NSNumber), y: CGFloat(y as! NSNumber), width: CGFloat(width as! NSNumber), height: CGFloat(height as! NSNumber))
}

extension CGRect {
    
    var screenWidth:CGFloat {
        return UIScreen.mainScreen().bounds.size.width
    }
    
    var screenHeight:CGFloat {
        return UIScreen.mainScreen().bounds.size.height
    }
    
    private var widthRatio:CGFloat {
        switch defaultType {
        case .ip5:
            return screenWidth / 320
        case .ip6:
            return screenWidth / 375
        case .ip6p:
            return screenWidth / 414
        }
        
    }
    
    private var heightRatio:CGFloat {
        switch defaultType {
        case .ip5:
            return (screenHeight / 568) <= 1 ? 1 : (screenHeight / 568)
        case .ip6:
            return (screenHeight / 667) <= 1 ? 1 : (screenHeight / 667)
        case .ip6p:
            return (screenHeight / 736) <= 1 ? 1 : (screenHeight / 736)
        }
    }
    
    init(x:CGFloat,y:CGFloat,width:CGFloat,height:CGFloat) {
        
        self.origin = CGPointZero
        self.size = CGSizeZero
        self.origin.x = x * widthRatio
        self.origin.y = y * heightRatio
        self.size.width = width * widthRatio
        self.size.height = height * heightRatio
    }
    
    var relativeCenter:CGPoint {
        return CGPointMake((self.origin.x + self.size.width) / widthRatio, (self.origin.y + self.size.height) / heightRatio)
    }
    
    var relativeWidth:CGFloat {
        return self.size.width / widthRatio
    }
    
    var relativeheight:CGFloat {
        return self.size.height / heightRatio
    }
    
    var relativeX:CGFloat {
        return self.origin.x / widthRatio
    }
    
    var relativeY:CGFloat {
        return self.origin.y / widthRatio
    }
    
    mutating func setRelativeCenter(center:CGPoint) {
        self.origin.x = center.x * widthRatio
        self.origin.y = center.x * heightRatio
    }
    
    mutating func setRelativeWidth(width:CGFloat) {
        self.size.width = width * widthRatio
    }
    
    mutating func setRelativeHeight(height:CGFloat) {
        self.size.height = height * heightRatio
    }
    
    mutating func setRelativeX(x:CGFloat) {
        self.origin.x = x * widthRatio
    }
    
    mutating func setRelativeY(y:CGFloat) {
        self.origin.y = y * heightRatio
    }
    
    func relativeRect() -> CGRect {
        return CGRectMake(relativeX, relativeY, relativeWidth, relativeheight)
    }
}