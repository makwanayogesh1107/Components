//
//  ForgotPasswordVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/2/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class ForgotPasswordVC: BaseViewController {

    var scrollView:TPKeyboardAvoidingScrollView!
    var txtEmail:TCTextField!
    var lblMessage:UILabel!
    var btnNext:UIButton!
    var strAlertMessage:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Forgot Password"

        //ScrollView
        scrollView = TPKeyboardAvoidingScrollView(frame:TCRectMake(x: 0, y: 0, width: 320, height: 568))
        self.view.addSubview(scrollView)
        
        //New user
        lblMessage = UILabel(frame: TCRectMake(x: 0, y: 100, width: 320, height: 100))
        lblMessage.text = "Well ! This happens to best of us, please\nprovide your email id we will get back\nto your through it"
        lblMessage.textColor = Color.textColor
        lblMessage.numberOfLines = 0
        lblMessage.textAlignment = NSTextAlignment.Center
        lblMessage.font = Font(FontName.HelveticaNeue, size: 15)
        scrollView.addSubview(lblMessage)
        
        //Textbox Email
        txtEmail = TCTextField(frame:TCRectMake(x: 45,y: lblMessage.frame.relativeheight + lblMessage.frame.relativeY + 35,width: 230,height: 45))
        txtEmail.setGUI("Email")
        scrollView.addSubview(txtEmail)
        
        //Next Button
        btnNext = UIButton(frame:TCRectMake(x: 45,y: txtEmail.frame.relativeheight + txtEmail.frame.relativeY + 35,width: 230,height: 45))
        btnNext.setTitle("Next", forState: UIControlState.Normal)
        btnNext.addTarget(self, action: Selector("tappedOnNext"), forControlEvents: UIControlEvents.TouchUpInside)
        btnNext.layer.cornerRadius = 5
        btnNext.titleLabel?.font = Font(FontName.HelveticaNeueBold, size: 14)
        btnNext.backgroundColor = Color.themeRed
        btnNext.setTitleColor(UIColor.grayColor(), forState: .Highlighted)
        scrollView.addSubview(btnNext)
        
        scrollView.contentSize = CGSizeMake(Screen.width, btnNext.frame.relativeheight + btnNext.frame.relativeY + 150)
    }
    func tappedOnNext()
    {
        if txtEmail.text?.isEmpty == true
        {
            strAlertMessage = "Please enter email."
        }
        else if isValidEmail(txtEmail.text!) == false
        {
            strAlertMessage = "Please enter valid email."
        }
        else
        {
            strAlertMessage = "Please check email address."
        }
        print("tapped on next")
        TCAlert().show(alertTitle, message:strAlertMessage, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
}
