//
//  EditProfileVC.swift
//  Emergency SMS
//
//  Created by Pankaj Yogesh on 5/4/16.
//  Copyright © 2016 Technocracker. All rights reserved.
//

import UIKit

class EditProfileVC: BaseViewController
{

    var scrollView:TPKeyboardAvoidingScrollView!
    var txtFirst:TCTextField!
    var txtLast:TCTextField!
    var txtEmail:TCTextField!
    var txtPass:TCTextField!
    var txtConFass:TCTextField!
    var txtMobile:TCTextField!
    var txtSecurityQ:TCTextField!
    var txtAnswer:TCTextField!
    var btnUserProfile:UIButton!
    var strAlertMessage:String!
    var isImageChnage = false
    var imgProfile:UIImageView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Edit Profile"
        
        let btnMenu = UIButton(frame:CGRectMake(10,20,34,34))
        btnMenu.setImage(UIImage(named:"menu_icon"), forState: UIControlState.Normal)
        btnMenu.addTarget(self, action:"openSlider", forControlEvents: UIControlEvents.TouchUpInside)
        self.viewHeader.addSubview(btnMenu)
        
        let btnSave = UIButton(frame:CGRectMake(Screen.width - 50,20,34,34))
        btnSave.setImage(UIImage(named:"save_icon"), forState: UIControlState.Normal)
        btnSave.addTarget(self, action:"btnSaveClick", forControlEvents: UIControlEvents.TouchUpInside)
        self.viewHeader.addSubview(btnSave)
        
        scrollView = TPKeyboardAvoidingScrollView(frame:TCRectMake(x: 0, y: 0, width: 320, height: 568))
        self.view.addSubview(scrollView)
        
        btnUserProfile = UIButton(frame: TCRectMake(x:110, y: 30, width: 100, height: 20))
        btnUserProfile.setImage(UIImage(named: "imgUserProfile"), forState: UIControlState.Normal)
        btnUserProfile.adjustsImageWhenHighlighted = false
        btnUserProfile.layer.cornerRadius = btnUserProfile.frame.size.height / 2
        btnUserProfile.clipsToBounds = true
        btnUserProfile.addTarget(self, action: Selector("tappedOnCamera"), forControlEvents: UIControlEvents.TouchUpInside)
        //scrollView.addSubview(btnUserProfile)
        
        imgProfile = UIImageView(frame:btnUserProfile.frame)
        imgProfile.contentMode = .ScaleAspectFill
        
        
        let lblFirstName = UILabel(frame: TCRectMake(x:35, y:btnUserProfile.frame.relativeY + btnUserProfile.frame.relativeheight, width: 100, height: 20))
        lblFirstName.setGUI("First Name")
        scrollView.addSubview(lblFirstName)
        
        txtFirst = TCTextField(frame:TCRectMake(x: 35,y:lblFirstName.frame.relativeheight + lblFirstName.frame.relativeY + 5,width: 250,height: 45))
        txtFirst.setGUI("First Name")
        scrollView.addSubview(txtFirst)
        
        let lblLastName = UILabel(frame: TCRectMake(x:35, y:txtFirst.frame.relativeY + txtFirst.frame.relativeheight + 10, width: 100, height: 20))
        lblLastName.setGUI("Last Name")
        scrollView.addSubview(lblLastName)
        
        txtLast = TCTextField(frame:TCRectMake(x: 35,y:lblLastName.frame.relativeheight + lblLastName.frame.relativeY + 5,width: 250,height: 45))
        txtLast.setGUI("Last Name")
        scrollView.addSubview(txtLast)
        
        let lblMobile = UILabel(frame: TCRectMake(x:35, y:txtLast.frame.relativeY + txtLast.frame.relativeheight + 10, width: 100, height: 20))
        lblMobile.setGUI("Mobile Number")
        scrollView.addSubview(lblMobile)
        
        txtMobile = TCTextField(frame:TCRectMake(x: 35,y:lblMobile.frame.relativeheight + lblMobile.frame.relativeY + 5,width: 250,height: 45))
        txtMobile.setGUI("Mobile Number")
        txtMobile.keyboardType = .NumberPad
        scrollView.addSubview(txtMobile)
        
        let lblEmail = UILabel(frame: TCRectMake(x:35, y:txtMobile.frame.relativeY + txtMobile.frame.relativeheight + 10, width: 100, height: 20))
        lblEmail.setGUI("Email")
        scrollView.addSubview(lblEmail)
        
        txtEmail = TCTextField(frame:TCRectMake(x: 35,y:lblEmail.frame.relativeheight + lblEmail.frame.relativeY + 5,width: 250,height: 45))
        txtEmail.setGUI("Email")
        txtEmail.enabled = false
        txtEmail.keyboardType = .EmailAddress
        
        scrollView.addSubview(txtEmail)
        
        let lblPass = UILabel(frame: TCRectMake(x:35, y:txtEmail.frame.relativeY + txtEmail.frame.relativeheight + 10, width: 100, height: 20))
        lblPass.setGUI("Password")
        scrollView.addSubview(lblPass)
        
        txtPass = TCTextField(frame:TCRectMake(x: 35,y:lblPass.frame.relativeheight + lblPass.frame.relativeY + 5,width: 250,height: 45))
        txtPass.setGUI("Password")
        txtPass.secureTextEntry = true
        scrollView.addSubview(txtPass)
        
        let lblConfPass = UILabel(frame: TCRectMake(x:35, y:txtPass.frame.relativeY + txtPass.frame.relativeheight + 10, width: 100, height: 20))
        lblConfPass.setGUI("Confirm Password")
        scrollView.addSubview(lblConfPass)
        
        txtConFass = TCTextField(frame:TCRectMake(x: 35,y:lblConfPass.frame.relativeheight + lblConfPass.frame.relativeY + 5,width: 250,height: 45))
        txtConFass.setGUI("Confirm Password")
        txtConFass.secureTextEntry = true
        scrollView.addSubview(txtConFass)
        
        let lblSecurityQ = UILabel(frame: TCRectMake(x:35, y:txtConFass.frame.relativeY + txtConFass.frame.relativeheight + 10, width: 100, height: 20))
        lblSecurityQ.setGUI("Question 1")
        scrollView.addSubview(lblSecurityQ)
        
        txtSecurityQ = TCTextField(frame:TCRectMake(x: 35,y:lblSecurityQ.frame.relativeheight + lblSecurityQ.frame.relativeY + 5,width: 250,height: 45))
        txtSecurityQ.setGUI("Choose a security questions")
        txtSecurityQ.setInputTypeList([
            "What is Last Name of thr teacher who gave you first faling grade",
            "Name your favourite pop singer",
            "Write s wolrd that explain you best"
            ])
        txtSecurityQ.setInputHeaderWith(Color.themeRed, textColor:UIColor.whiteColor(), doneTitle:"Done", prevTitle:"", nextTitle:"Next", doneBlock: { (textField) -> () in
            
            }, nextBlock: { (textField) -> () in
                self.txtAnswer.becomeFirstResponder()
                
            }) { (textField) -> () in
                
        }
        scrollView.addSubview(txtSecurityQ)
        
        let lblAns = UILabel(frame: TCRectMake(x:35, y:txtSecurityQ.frame.relativeY + txtSecurityQ.frame.relativeheight + 10, width: 100, height: 20))
        lblAns.setGUI("Answer")
        scrollView.addSubview(lblAns)
        
        txtAnswer = TCTextField(frame:TCRectMake(x: 35,y:lblAns.frame.relativeheight + lblAns.frame.relativeY + 5,width: 250,height: 45))
        txtAnswer.setGUI("Answer")
        scrollView.addSubview(txtAnswer)
        
        scrollView.contentSize = CGSizeMake(Screen.width,txtAnswer.frame.origin.y + txtAnswer.frame.size.height + 10)
        
        setUserData()
        
    }
    func setUserData() {
    
        print(Helper.sharedInstance.dictUser)
        txtFirst.text = Helper.sharedInstance.dictUser["firstName"] as? String
        txtLast.text = Helper.sharedInstance.dictUser["lastName"] as? String
        txtMobile.text = Helper.sharedInstance.dictUser["mobile"] as? String
        txtEmail.text = Helper.sharedInstance.dictUser["email"] as? String
        txtSecurityQ.text = Helper.sharedInstance.dictUser["question"] as? String
        txtAnswer.text = Helper.sharedInstance.dictUser["answer"] as? String
    }
    func isFormValid() ->Bool
    {
        if txtFirst.text?.isEmpty == true
        {
            strAlertMessage = "Please enter first name."
            return false
        }
        else if containsOnlyLetters(txtFirst.text!) == false
        {
            strAlertMessage = "First name should only contain alphabets."
            return false
        }
        else if txtLast.text?.isEmpty == true
        {
            strAlertMessage = "Please enter last name."
            return false
        }
        else if containsOnlyLetters(txtLast.text!)  == false
        {
            strAlertMessage = "Last name should only contain alphabets."
            return false
        }
        else if txtEmail.text?.isEmpty == true
        {
            strAlertMessage = "Please enter email."
            return false
        }
        else if isValidEmail(txtEmail.text!) == false
        {
            strAlertMessage = "Please enter valid email."
            return false
        }
        else if txtMobile.text?.isEmpty == true
        {
            strAlertMessage = "Enter mobile number."
            return false
        }
        else if isValidPhoneNumber(txtMobile.text!) == true
        {
            strAlertMessage = "Enter valid mobile number."
            return false
        }
        else if isValidRange(8, maxNo: 12, strMessage: txtMobile.text!)
        {
            strAlertMessage = "Please enter valid phone number."
            return false
        }
        else if txtPass.text?.isEmpty == true
        {
            strAlertMessage = "Please enter password."
            return false
        }
        else if isValidRange(8, maxNo: 16, strMessage: txtPass.text!)
        {
            strAlertMessage = "Please enter password between 8 to 16 characters."
            return false
        }
        else if isPasswordSame(txtPass.text!, confirmPassword: txtConFass.text!) == false
        {
            strAlertMessage = "Password does not match."
            return false
        }
        else if txtSecurityQ.text?.isEmpty == true
        {
            strAlertMessage = "Choose a security question."
            return false
        }
        else if txtAnswer.text?.isEmpty == true
        {
            strAlertMessage = "Please enter answer."
            return false
        }
        else
        {
            strAlertMessage = "Registration successfully."
            return true
        }
    }
    func openSlider()
    {
        self.openLeft()
    }
    func tappedOnCamera()
    {
        print("Tapped on camera")
        
        TCImagePicker.sharedInstance().openImagePicker("Select Image", cancelTitle:"Cancel", cameraTitle:"Camera", galleryTitle:"Library", isImage:true, isMultipleSelection:false, completeHandler: { (success, arrAssert) -> Void in
            
            self.btnUserProfile.setImage(arrAssert[0].thumbnailImage, forState: UIControlState.Normal)
            //self.imageUser = arrAssert[0].thumbnailImage
            
            }) { (error) -> (Void) in
                
        }
        
        
    }
    func btnSaveClick()
    {
        
        if isFormValid()
        {
            updateProfileApi()
        }
        else
        {
            print("Form is not valid : \(strAlertMessage)")
            TCAlert().show(alertTitle, message:strAlertMessage, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
            })
        }
    }
    
    func updateProfileApi()
    {
        
        var dictUser = [String : AnyObject]()
        
        
        dictUser["firstName"] = txtFirst.text!
        dictUser["lastName"] = txtLast.text!
        dictUser["email"] = txtEmail.text!
        dictUser["mobile"] =  txtMobile.text!
        dictUser["question"] = txtSecurityQ.text!
        dictUser["answer"] = txtAnswer.text!
        dictUser["password"] = txtPass.text!
        dictUser["id"] = Helper.sharedInstance.dictUser["registerId"]
        dictUser["registerId"] = Helper.sharedInstance.dictUser["registerId"]
        
        
        /*if self.imageUser != nil {
        let imgData = UIImageJPEGRepresentation(self.imageUser!, 0.7)
        dictUser["file"] = imgData!
        dictUser["fileName"] = "12345678.png"
        dictUser["mimeType"] = "image/png"
        dictUser["fileKey"] =  "profile"
        
        }*/
        
        
        self.view.endEditing(true)
        Helper.sharedInstance.request.requestFor(requestURL:baseURL + updateProfile,
            type: .POST,
            parameters:dictUser).onProgress { (request, total, sent, type) -> () in
            }.onSuccess { (request, response, error) -> () in
                
                dispatch_async(dispatch_get_main_queue(),{
                    if error != nil
                    {
                        print(error?.localizedDescription)
                        TCAlert.sharedInstance().show(alertTitle, message:(error?.localizedDescription)!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                            
                        })
                    }
                    else
                    {
                        print(response)
                        if (response!["data"]!!["status"] as? NSNumber)?.integerValue == 1
                        {
                            let errorMsg = response!["data"]!!["msg"] as? String
                            TCAlert.sharedInstance().show(alertTitle, message:(errorMsg)!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                                NSUserDefaults.standardUserDefaults().setObject(dictUser, forKey:"userInfro")
                            })
                            
                        }
                        else
                        {
                            let errorMsg = response!["data"]!!["msg"] as? String
                            TCAlert.sharedInstance().show(alertTitle, message:errorMsg!, buttonsTitle:["Ok"], willHideAlert: { (buttonIndex) -> Void in
                            })
                        }
                    }
                })
        }
        
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()

    }
}

extension UILabel {
    
    func setGUI(title:String,textColor:UIColor = Color.textColor , font:UIFont = Font(FontName.HelveticaNeue, size: 12)){
        self.text = title
        self.textColor = textColor
        self.font = font
    }

}
